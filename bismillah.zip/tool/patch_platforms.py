#!/usr/bin/env python3
"""Patches the platform folders created by `flutter create` for azan alarms, GPS and notifications."""
import os, re, shutil, sys

root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def rd(p): return open(os.path.join(root, p), encoding='utf-8').read()
def wr(p, s): open(os.path.join(root, p), 'w', encoding='utf-8').write(s)

# ---------------- Android ----------------
man = 'android/app/src/main/AndroidManifest.xml'
if os.path.exists(os.path.join(root, man)):
    s = rd(man)
    perms = ['INTERNET', 'ACCESS_FINE_LOCATION', 'ACCESS_COARSE_LOCATION', 'POST_NOTIFICATIONS', 'SCHEDULE_EXACT_ALARM',
             'USE_EXACT_ALARM', 'RECEIVE_BOOT_COMPLETED', 'VIBRATE', 'WAKE_LOCK']
    add = ''.join(f'    <uses-permission android:name="android.permission.{p}"/>\n' for p in perms
                  if f'android.permission.{p}"' not in s)
    s = s.replace('<application', add + '    <application', 1) if add else s
    s = re.sub(r'android:label="[^"]*"', 'android:label="Bismillah Islam"', s, count=1)
    if 'ScheduledNotificationReceiver' not in s:
        rec = '''
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
                <action android:name="android.intent.action.QUICKBOOT_POWERON" />
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
            </intent-filter>
        </receiver>
'''
        s = s.replace('</application>', rec + '    </application>', 1)
    wr(man, s)
    raw = os.path.join(root, 'android/app/src/main/res/raw')
    os.makedirs(raw, exist_ok=True)
    for f in os.listdir(os.path.join(root, 'assets/azan')):
        shutil.copy(os.path.join(root, 'assets/azan', f), raw)  # same files, no duplicate copy in the project
    for gp in ['android/app/build.gradle.kts', 'android/app/build.gradle']:
        if not os.path.exists(os.path.join(root, gp)): continue
        g = rd(gp)
        kts = gp.endswith('.kts')
        if 'coreLibraryDesugaring' not in g:
            if kts:
                g = re.sub(r'compileOptions\s*\{', 'compileOptions {\n        isCoreLibraryDesugaringEnabled = true', g, count=1)
                g = g.rstrip() + '\n\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n}\n'
            else:
                g = re.sub(r'compileOptions\s*\{', 'compileOptions {\n        coreLibraryDesugaringEnabled true', g, count=1)
                g = g.rstrip() + '\n\ndependencies {\n    coreLibraryDesugaring "com.android.tools:desugar_jdk_libs:2.1.4"\n}\n'
        g = re.sub(r'minSdk(Version)?\s*=?\s*(flutter\.minSdkVersion|\d+)', lambda m: 'minSdk = 23' if kts else 'minSdkVersion 23', g, count=1)
        wr(gp, g)
        print('patched', gp)
    print('android: ok')

# ---------------- iOS ----------------
plist = 'ios/Runner/Info.plist'
if os.path.exists(os.path.join(root, plist)):
    s = rd(plist)
    keys = {
        'NSLocationWhenInUseUsageDescription': 'Your location is used to calculate accurate prayer times and the Qibla direction.',
        'CFBundleDisplayName': 'Bismillah Islam',
    }
    for k, v in keys.items():
        if k not in s:
            s = s.replace('</dict>\n</plist>', f'\t<key>{k}</key>\n\t<string>{v}</string>\n</dict>\n</plist>')
    wr(plist, s)
    if os.path.isdir(os.path.join(root, 'native/ios')):
        for f in os.listdir(os.path.join(root, 'native/ios')):
            shutil.copy(os.path.join(root, 'native/ios', f), os.path.join(root, 'ios/Runner', f))
    ad = 'ios/Runner/AppDelegate.swift'
    if os.path.exists(os.path.join(root, ad)):
        a = rd(ad)
        if 'UNUserNotificationCenter' not in a:
            a = a.replace('import Flutter', 'import Flutter\nimport UserNotifications', 1)
            a = a.replace('GeneratedPluginRegistrant.register(with: self)',
                          'GeneratedPluginRegistrant.register(with: self)\n    if #available(iOS 10.0, *) {\n      UNUserNotificationCenter.current().delegate = self as UNUserNotificationCenterDelegate\n    }', 1)
            wr(ad, a)
    print('ios: ok  (now add the 4 azan_*.aiff files in ios/Runner to the Runner target in Xcode: right-click Runner > Add Files)')

# ---------------- Web ----------------
idx = 'web/index.html'
if os.path.exists(os.path.join(root, idx)):
    s = rd(idx)
    s = re.sub(r'<title>.*?</title>', '<title>Bismillah Islam</title>', s)
    wr(idx, s)
    print('web: ok')
