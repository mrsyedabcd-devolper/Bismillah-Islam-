/// Tabular (arithmetical) Hijri calendar. Accurate to about one day; moon sighting can differ.
class HDate {
  final int y, m, d;
  const HDate(this.y, this.m, this.d);
}

int hToJdn(int y, int m, int d) => d + (29.5 * (m - 1)).ceil() + (y - 1) * 354 + (3 + 11 * y) ~/ 30 + 1948438;

int gToJdn(DateTime g) {
  final a = (14 - g.month) ~/ 12;
  final yy = g.year + 4800 - a;
  final mm = g.month + 12 * a - 3;
  return g.day + (153 * mm + 2) ~/ 5 + 365 * yy + yy ~/ 4 - yy ~/ 100 + yy ~/ 400 - 32045;
}

DateTime jdnToG(int j) {
  final a = j + 32044;
  final b = (4 * a + 3) ~/ 146097;
  final c = a - (146097 * b) ~/ 4;
  final d = (4 * c + 3) ~/ 1461;
  final e = c - (1461 * d) ~/ 4;
  final m = (5 * e + 2) ~/ 153;
  final day = e - (153 * m + 2) ~/ 5 + 1;
  final month = m + 3 - 12 * (m ~/ 10);
  final year = 100 * b + d - 4800 + m ~/ 10;
  return DateTime(year, month, day);
}

HDate hFromJdn(int j) {
  var y = ((j - 1948439) / 354.36667).floor() + 1;
  while (hToJdn(y + 1, 1, 1) <= j) {
    y++;
  }
  while (hToJdn(y, 1, 1) > j) {
    y--;
  }
  var m = 1;
  while (m < 12 && hToJdn(y, m + 1, 1) <= j) {
    m++;
  }
  return HDate(y, m, j - hToJdn(y, m, 1) + 1);
}
