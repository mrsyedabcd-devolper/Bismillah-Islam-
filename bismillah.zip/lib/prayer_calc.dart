import 'dart:math' as m;

/// Prayer time calculation (PrayTimes.org algorithm), pure Dart, works offline.
class CalcMethod {
  final String id;
  final String name;
  final double fajr;
  final double? isha; // angle
  final int? ishaMin; // minutes after maghrib
  final double? maghribAngle;
  const CalcMethod(this.id, this.name, this.fajr, {this.isha, this.ishaMin, this.maghribAngle});
}

const List<CalcMethod> kMethods = [
  CalcMethod('karachi', 'University of Islamic Sciences, Karachi', 18, isha: 18),
  CalcMethod('mwl', 'Muslim World League', 18, isha: 17),
  CalcMethod('isna', 'ISNA (North America)', 15, isha: 15),
  CalcMethod('egypt', 'Egyptian General Authority', 19.5, isha: 17.5),
  CalcMethod('makkah', 'Umm al-Qura, Makkah', 18.5, ishaMin: 90),
  CalcMethod('gulf', 'Gulf Region', 19.5, ishaMin: 90),
  CalcMethod('kuwait', 'Kuwait', 18, isha: 17.5),
  CalcMethod('qatar', 'Qatar', 18, ishaMin: 90),
  CalcMethod('singapore', 'Singapore / Malaysia', 20, isha: 18),
  CalcMethod('turkey', 'Diyanet, Turkey', 18, isha: 17),
  CalcMethod('tehran', 'Tehran (Geophysics)', 17.7, isha: 14, maghribAngle: 4.5),
];

CalcMethod methodById(String id) => kMethods.firstWhere((e) => e.id == id, orElse: () => kMethods.first);

class DayTimes {
  /// All values are UTC instants.
  final DateTime fajr, sunrise, dhuhr, asr, maghrib, isha;
  final DateTime midnight; // islamic midnight (sunset -> next fajr midpoint approx)
  final DateTime duha; // approx 20 min after sunrise
  const DayTimes(this.fajr, this.sunrise, this.dhuhr, this.asr, this.maghrib, this.isha, this.midnight, this.duha);
}

class PrayerCalc {
  static const double _d2r = m.pi / 180;
  static double _sin(double d) => m.sin(d * _d2r);
  static double _cos(double d) => m.cos(d * _d2r);
  static double _tan(double d) => m.tan(d * _d2r);
  static double _asin(double x) => m.asin(x) / _d2r;
  static double _acos(double x) => (x.abs() > 1) ? double.nan : m.acos(x) / _d2r;
  static double _atan2(double y, double x) => m.atan2(y, x) / _d2r;
  static double _acot(double x) => m.atan(1 / x) / _d2r;
  static double _fixAngle(double a) => a - 360 * (a / 360).floor();
  static double _fixHour(double h) => h - 24 * (h / 24).floor();

  static double _julian(int y, int mo, int d) {
    if (mo <= 2) {
      y -= 1;
      mo += 12;
    }
    final a = (y / 100).floor();
    final b = 2 - a + (a / 4).floor();
    return (365.25 * (y + 4716)).floorToDouble() + (30.6001 * (mo + 1)).floorToDouble() + d + b - 1524.5;
  }

  static List<double> _sunPos(double jd) {
    final dd = jd - 2451545.0;
    final g = _fixAngle(357.529 + 0.98560028 * dd);
    final q = _fixAngle(280.459 + 0.98564736 * dd);
    final l = _fixAngle(q + 1.915 * _sin(g) + 0.020 * _sin(2 * g));
    final e = 23.439 - 0.00000036 * dd;
    final ra = _fixHour(_atan2(_cos(e) * _sin(l), _cos(l)) / 15);
    return [_asin(_sin(e) * _sin(l)), q / 15 - ra]; // declination, equation of time
  }

  /// Compute times for a local calendar date at [lat],[lng] with UTC offset [offsetMin].
  /// [asrFactor] 1 = Shafi/Maliki/Hanbali, 2 = Hanafi. [adjust] minutes per prayer key.
  static DayTimes compute({
    required DateTime date,
    required double lat,
    required double lng,
    required int offsetMin,
    required CalcMethod method,
    int asrFactor = 1,
    Map<String, int> adjust = const {},
    double? customFajr,
    double? customIsha,
  }) {
    final tz = offsetMin / 60.0;
    final jd = _julian(date.year, date.month, date.day) - lng / (15 * 24);
    double mid(double t) => _fixHour(12 - _sunPos(jd + t)[1]);
    double sunAngleTime(double angle, double t, {bool ccw = false}) {
      final decl = _sunPos(jd + t)[0];
      final noon = mid(t);
      final x = (-_sin(angle) - _sin(decl) * _sin(lat)) / (_cos(decl) * _cos(lat));
      final tt = _acos(x) / 15;
      return noon + (ccw ? -tt : tt);
    }

    double asrTime(int f, double t) {
      final decl = _sunPos(jd + t)[0];
      final angle = -_acot(f + _tan((lat - decl).abs()));
      return sunAngleTime(angle, t);
    }

    final fajrAngle = customFajr ?? method.fajr;
    double fajr = sunAngleTime(fajrAngle, 5 / 24, ccw: true);
    double sunrise = sunAngleTime(0.833, 6 / 24, ccw: true);
    double dhuhr = mid(12 / 24);
    double asr = asrTime(asrFactor, 13 / 24);
    double sunset = sunAngleTime(0.833, 18 / 24);
    double maghrib = method.maghribAngle != null ? sunAngleTime(method.maghribAngle!, 18 / 24) : sunset;
    final ishaAngle = customIsha ?? method.isha;
    double isha = (method.ishaMin != null && customIsha == null) ? double.nan : sunAngleTime(ishaAngle ?? 17, 18 / 24);

    final shift = tz - lng / 15;
    fajr += shift;
    sunrise += shift;
    dhuhr += shift;
    asr += shift;
    sunset += shift;
    maghrib += shift;
    isha += shift;

    // high latitude handling (angle based)
    final night = _fixHour(sunrise - sunset);
    double portion(double angle) => (angle / 60) * night;
    double adjustHL(double time, double base, double angle, {bool ccw = false}) {
      final p = portion(angle);
      final diff = ccw ? _fixHour(base - time) : _fixHour(time - base);
      if (time.isNaN || diff > p) return base + (ccw ? -p : p);
      return time;
    }

    if (sunrise.isNaN || sunset.isNaN) {
      // polar day/night: fall back to dhuhr +- 6h
      sunrise = dhuhr - 6;
      sunset = dhuhr + 6;
      maghrib = sunset;
    }
    fajr = adjustHL(fajr, sunrise, fajrAngle, ccw: true);
    if (method.ishaMin != null && customIsha == null) {
      isha = maghrib + method.ishaMin! / 60;
    } else {
      isha = adjustHL(isha, sunset, ishaAngle ?? 17);
    }

    final midnightH = sunset + _fixHour(fajr + 24 - sunset) / 2;
    final duhaH = sunrise + 20 / 60;

    final base = DateTime.utc(date.year, date.month, date.day);
    DateTime inst(double h, [int adj = 0]) {
      final mins = (_fixHour(h) * 60 + 0.5).floor() + adj;
      return base.add(Duration(minutes: mins - offsetMin));
    }

    final maghribI = inst(maghrib, adjust['maghrib'] ?? 0);
    DateTime afterMaghrib(DateTime d) => d.isBefore(maghribI) ? d.add(const Duration(days: 1)) : d;

    return DayTimes(
      inst(fajr, adjust['fajr'] ?? 0),
      inst(sunrise, adjust['sunrise'] ?? 0),
      inst(dhuhr, adjust['dhuhr'] ?? 0),
      inst(asr, adjust['asr'] ?? 0),
      maghribI,
      afterMaghrib(inst(isha, adjust['isha'] ?? 0)),
      afterMaghrib(inst(midnightH)),
      inst(duhaH),
    );
  }

  static const double kaabaLat = 21.422487, kaabaLng = 39.826206;

  /// Bearing in degrees clockwise from true north.
  static double qiblaBearing(double lat, double lng) {
    final dl = (kaabaLng - lng) * _d2r;
    final p1 = lat * _d2r, p2 = kaabaLat * _d2r;
    final y = m.sin(dl);
    final x = m.cos(p1) * m.tan(p2) - m.sin(p1) * m.cos(dl);
    return (m.atan2(y, x) / _d2r + 360) % 360;
  }

  static double distanceToKaabaKm(double lat, double lng) {
    const r = 6371.0;
    final dLat = (kaabaLat - lat) * _d2r, dLng = (kaabaLng - lng) * _d2r;
    final a = m.pow(m.sin(dLat / 2), 2) + m.cos(lat * _d2r) * m.cos(kaabaLat * _d2r) * m.pow(m.sin(dLng / 2), 2);
    return 2 * r * m.asin(m.sqrt(a));
  }
}
