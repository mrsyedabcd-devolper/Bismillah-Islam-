import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'screens/azkar.dart';
import 'screens/home.dart';
import 'screens/qibla.dart';
import 'screens/settings.dart';
import 'screens/tasbeeh.dart';
import 'services.dart';
import 'state.dart';
import 'theme.dart';
import 'widgets.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await app.init();
  await NotifService.instance.init();
  runApp(const OrbitIslamApp());
}

class OrbitIslamApp extends StatelessWidget {
  const OrbitIslamApp({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: app,
        builder: (context, _) => MaterialApp(
          title: 'Bismillah Islam',
          debugShowCheckedModeBanner: false,
          themeMode: app.themeMode,
          theme: buildTheme(Pal.light),
          darkTheme: buildTheme(Pal.dark),
          builder: (context, child) => Directionality(textDirection: app.rtl ? TextDirection.rtl : TextDirection.ltr, child: child!),
          home: const Shell(),
        ),
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int tab = 0;

  @override
  void initState() {
    super.initState();
    app.tabNotifier.addListener(_onTab);
  }

  void _onTab() => setState(() => tab = app.tabNotifier.value);

  @override
  void dispose() {
    app.tabNotifier.removeListener(_onTab);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = pal(context);
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: p.dark ? Brightness.light : Brightness.dark,
    ));
    final pages = const [HomeScreen(), AzkarScreen(), TasbeehScreen(), QiblaScreen(), SettingsScreen()];
    return Scaffold(
      body: Stack(children: [
        SafeArea(bottom: false, child: IndexedStack(index: tab, children: pages)),
        Positioned(left: 14, right: 14, bottom: 0, child: SafeArea(top: false, child: Padding(padding: const EdgeInsets.only(bottom: 10), child: _NavBar(tab: tab, onTap: (i) => app.tabNotifier.value = i)))),
        ValueListenableBuilder<String?>(
          valueListenable: app.azanPlaying,
          builder: (_, v, __) => v == null ? const SizedBox.shrink() : Positioned(top: 0, left: 0, right: 0, child: SafeArea(child: _AzanBanner(prayer: v))),
        ),
      ]),
    );
  }
}

class _AzanBanner extends StatelessWidget {
  final String prayer;
  const _AzanBanner({required this.prayer});
  @override
  Widget build(BuildContext context) {
    final p = pal(context);
    return Container(
      margin: const EdgeInsets.all(12),
      padding: const EdgeInsets.fromLTRB(18, 12, 12, 12),
      decoration: BoxDecoration(gradient: LinearGradient(colors: p.hero), borderRadius: BorderRadius.circular(22)),
      child: Row(children: [
        const Icon(Icons.volume_up_rounded, color: Colors.white),
        const SizedBox(width: 10),
        Expanded(child: Text('${app.t(prayer)} · ${app.t('azan_on_time')}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: OC.primaryDeep),
          onPressed: app.stopAzan,
          child: Text(app.t('stop')),
        ),
      ]),
    );
  }
}

class _NavBar extends StatelessWidget {
  final int tab;
  final ValueChanged<int> onTap;
  const _NavBar({required this.tab, required this.onTap});

  Widget item(BuildContext c, int i, IconData icon, String label) {
    final p = pal(c);
    final on = tab == i;
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => onTap(i),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 24, color: on ? p.primary : p.muted),
            const SizedBox(height: 2),
            Text(label, style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600, color: on ? p.primary : p.muted)),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = pal(context);
    return Container(
      height: 66,
      padding: const EdgeInsets.symmetric(horizontal: 6),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: p.border),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(p.dark ? .5 : .12), blurRadius: 24, offset: const Offset(0, 8))],
      ),
      child: Row(children: [
        item(context, 0, Icons.home_rounded, app.t('home')),
        item(context, 1, Icons.menu_book_rounded, app.t('azkar')),
        // center: big tasbeeh button
        Expanded(
          child: Center(
            child: GestureDetector(
              onTap: () => onTap(2),
              child: Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: p.hero, begin: Alignment.topLeft, end: Alignment.bottomRight),
                  shape: BoxShape.circle,
                  border: tab == 2 ? Border.all(color: p.gold, width: 2.5) : null,
                  boxShadow: [BoxShadow(color: p.primary.withOpacity(.4), blurRadius: 14, offset: const Offset(0, 6))],
                ),
                child: const Icon(Icons.touch_app_rounded, color: Colors.white, size: 26),
              ),
            ),
          ),
        ),
        item(context, 3, Icons.explore_rounded, app.t('qibla')),
        item(context, 4, Icons.settings_rounded, app.t('settings')),
      ]),
    );
  }
}
