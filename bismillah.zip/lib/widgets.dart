import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'state.dart';
import 'theme.dart';

Pal pal(BuildContext c) => Pal.of(c);

class AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final VoidCallback? onTap;
  final Color? color;
  const AppCard({super.key, required this.child, this.padding = const EdgeInsets.all(16), this.onTap, this.color});
  @override
  Widget build(BuildContext context) {
    final p = pal(context);
    return Container(
      decoration: BoxDecoration(
        color: color ?? p.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: p.border),
        boxShadow: [BoxShadow(color: OC.primaryDeep.withOpacity(p.dark ? 0 : .10), blurRadius: 24, offset: const Offset(0, 10), spreadRadius: -12)],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(24),
        child: InkWell(borderRadius: BorderRadius.circular(24), onTap: onTap, child: Padding(padding: padding, child: child)),
      ),
    );
  }
}

class ArabicText extends StatelessWidget {
  final String text;
  final double size;
  final Color? color;
  final TextAlign align;
  const ArabicText(this.text, {super.key, this.size = 26, this.color, this.align = TextAlign.right});
  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Text(text, textAlign: align, style: TextStyle(fontFamily: 'Amiri', fontSize: size, height: 2.0, color: color ?? pal(context).text)),
      );
}

class UrduText extends StatelessWidget {
  final String text;
  final double size;
  final Color? color;
  const UrduText(this.text, {super.key, this.size = 17, this.color});
  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Text(text, textAlign: TextAlign.right, style: TextStyle(fontFamily: 'NotoNastaliqUrdu', fontSize: size, height: 2.2, color: color ?? pal(context).text)),
      );
}

class Pill extends StatelessWidget {
  final String text;
  final bool on;
  final VoidCallback? onTap;
  const Pill(this.text, {super.key, this.on = false, this.onTap});
  @override
  Widget build(BuildContext context) {
    final p = pal(context);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(color: on ? p.primary : p.surface2, borderRadius: BorderRadius.circular(999)),
        child: Text(text, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: on ? p.onPrimary : p.primary)),
      ),
    );
  }
}

class Sheet extends StatelessWidget {
  final String title;
  final Widget child;
  const Sheet({super.key, required this.title, required this.child});
  @override
  Widget build(BuildContext context) => SafeArea(
        child: Padding(
          padding: EdgeInsets.fromLTRB(20, 14, 20, 20 + MediaQuery.of(context).viewInsets.bottom),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(child: Container(width: 44, height: 4, decoration: BoxDecoration(color: pal(context).border, borderRadius: BorderRadius.circular(4)))),
            const SizedBox(height: 14),
            Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            Flexible(child: child),
          ]),
        ),
      );
}

Future<T?> showSheet<T>(BuildContext c, String title, Widget child) =>
    showModalBottomSheet<T>(context: c, isScrollControlled: true, showDragHandle: false, builder: (_) => Sheet(title: title, child: child));

void toast(BuildContext c, String msg) {
  ScaffoldMessenger.of(c).hideCurrentSnackBar();
  ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(msg), duration: const Duration(seconds: 2)));
}

Future<void> copyText(BuildContext c, String text) async {
  await Clipboard.setData(ClipboardData(text: text));
  toast(c, app.t('copied'));
}

Future<bool> confirm(BuildContext c, String msg) async {
  final r = await showDialog<bool>(
    context: c,
    builder: (_) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      content: Text(msg),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: Text(app.t('cancel'))),
        TextButton(onPressed: () => Navigator.pop(c, true), child: Text(app.t('delete'), style: TextStyle(color: pal(c).primary))),
      ],
    ),
  );
  return r ?? false;
}

class Loading extends StatelessWidget {
  const Loading({super.key});
  @override
  Widget build(BuildContext context) => Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        CircularProgressIndicator(color: pal(context).primary),
        const SizedBox(height: 12),
        Text(app.t('loading'), style: TextStyle(color: pal(context).muted)),
      ]));
}

class SearchBox extends StatelessWidget {
  final String hint;
  final ValueChanged<String> onChanged;
  final TextEditingController? controller;
  const SearchBox({super.key, required this.hint, required this.onChanged, this.controller});
  @override
  Widget build(BuildContext context) => TextField(
        controller: controller,
        onChanged: onChanged,
        decoration: InputDecoration(hintText: hint, prefixIcon: const Icon(Icons.search_rounded), isDense: true),
      );
}

/// Generic page scaffold using the design's rounded bar.
class AppPage extends StatelessWidget {
  final String title;
  final Widget body;
  final List<Widget>? actions;
  const AppPage({super.key, required this.title, required this.body, this.actions});
  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: app.rtl ? TextDirection.rtl : TextDirection.ltr,
        child: Scaffold(appBar: AppBar(title: Text(title), actions: actions), body: body),
      );
}
