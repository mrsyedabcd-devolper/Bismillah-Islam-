import 'package:flutter/material.dart';

class OC {
  // Bismillah Islam design tokens (from index.html design system)
  static const lightBg = Color(0xFFFFF6EC);
  static const lightSurface = Color(0xFFFFFFFF);
  static const lightSurface2 = Color(0xFFFFEFDD);
  static const lightBorder = Color(0xFFF3E2CF);
  static const lightText = Color(0xFF2B1D14);
  static const lightMuted = Color(0xFF8A7262);
  static const primary = Color(0xFFE8590C);
  static const primaryDeep = Color(0xFFA83E06);
  static const gold = Color(0xFFF2A93B);
  static const green = Color(0xFF3BAA6E);

  static const darkBg = Color(0xFF15100C);
  static const darkSurface = Color(0xFF221913);
  static const darkSurface2 = Color(0xFF2D2119);
  static const darkBorder = Color(0xFF3A2B20);
  static const darkText = Color(0xFFFBEFE3);
  static const darkMuted = Color(0xFFB39C8A);
  static const darkPrimary = Color(0xFFFF7A2F);
}

class Pal {
  final Color bg, surface, surface2, border, text, muted, primary, onPrimary, gold;
  final List<Color> hero;
  final bool dark;
  const Pal(this.bg, this.surface, this.surface2, this.border, this.text, this.muted, this.primary, this.onPrimary, this.gold, this.hero, this.dark);

  static const lightTheme = Pal(OC.lightBg, OC.lightSurface, OC.lightSurface2, OC.lightBorder, OC.lightText, OC.lightMuted, OC.primary, Colors.white, OC.gold,
      [Color(0xFFF26B1D), Color(0xFFA83E06)], false);
  static const darkTheme = Pal(OC.darkBg, OC.darkSurface, OC.darkSurface2, OC.darkBorder, OC.darkText, OC.darkMuted, OC.darkPrimary, Color(0xFF1A110B), Color(0xFFF6C35A),
      [Color(0xFF3A2418), Color(0xFF1E140E)], true);

  static Pal of(BuildContext c) => Theme.of(c).brightness == Brightness.dark ? darkTheme : lightTheme;
}

ThemeData buildTheme(Pal p) {
  final base = ThemeData(brightness: p.dark ? Brightness.dark : Brightness.light, useMaterial3: true, fontFamily: 'Poppins');
  return base.copyWith(
    scaffoldBackgroundColor: p.bg,
    colorScheme: ColorScheme.fromSeed(seedColor: OC.primary, brightness: p.dark ? Brightness.dark : Brightness.light).copyWith(
      primary: p.primary,
      onPrimary: p.onPrimary,
      surface: p.surface,
      onSurface: p.text,
    ),
    textTheme: base.textTheme.apply(bodyColor: p.text, displayColor: p.text, fontFamily: 'Poppins'),
    appBarTheme: AppBarTheme(backgroundColor: p.bg, foregroundColor: p.text, elevation: 0, scrolledUnderElevation: 0, centerTitle: false,
        titleTextStyle: TextStyle(fontFamily: 'Poppins', fontSize: 20, fontWeight: FontWeight.w700, color: p.text)),
    dividerColor: p.border,
    cardColor: p.surface,
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.all(Colors.white),
      trackColor: WidgetStateProperty.resolveWith((s) => s.contains(WidgetState.selected) ? p.primary : p.border),
      trackOutlineColor: WidgetStateProperty.all(Colors.transparent),
    ),
    sliderTheme: SliderThemeData(activeTrackColor: p.primary, thumbColor: p.primary, inactiveTrackColor: p.border),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: p.surface,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: p.border)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: p.border)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: p.primary, width: 1.5)),
    ),
    snackBarTheme: SnackBarThemeData(behavior: SnackBarBehavior.floating, backgroundColor: p.text, contentTextStyle: TextStyle(color: p.bg)),
    bottomSheetTheme: BottomSheetThemeData(backgroundColor: p.surface, shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28)))),
  );
}
