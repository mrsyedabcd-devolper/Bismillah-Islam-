import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'i18n.dart';
import 'prayer_calc.dart';
import 'services.dart';

const List<String> kPrayerKeys = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];
const List<String> kSounds = ['classic', 'makkah', 'alaqsa', 'fajr'];
const Map<String, String> kSoundNames = {
  'classic': 'Azan (classic)',
  'makkah': 'Makkah Azan',
  'alaqsa': 'Al-Aqsa Azan',
  'fajr': 'Fajr Azan',
};

class PrayerPref {
  bool enabled;
  String sound;
  String mode; // azan | notify | silent
  PrayerPref({this.enabled = true, this.sound = 'classic', this.mode = 'azan'});
  Map<String, dynamic> toJson() => {'e': enabled, 's': sound, 'm': mode};
  factory PrayerPref.fromJson(Map<String, dynamic> j) => PrayerPref(enabled: j['e'] ?? true, sound: j['s'] ?? 'classic', mode: j['m'] ?? 'azan');
}

class Loc {
  double lat, lng;
  String name;
  bool auto;
  int? offsetMin; // only for manual locations
  Loc(this.lat, this.lng, this.name, this.auto, this.offsetMin);
  Map<String, dynamic> toJson() => {'lat': lat, 'lng': lng, 'name': name, 'auto': auto, 'off': offsetMin};
  factory Loc.fromJson(Map<String, dynamic> j) => Loc((j['lat'] as num).toDouble(), (j['lng'] as num).toDouble(), j['name'] ?? '', j['auto'] ?? true, j['off']);
}

class Counter {
  String id;
  String name;
  String arabic;
  BigInt count;
  int target; // 0 = unlimited
  int round; // round size for lap counting, 0 = none
  Map<String, int> hist; // yyyy-MM-dd -> taps
  BigInt lifetime;
  Counter({required this.id, required this.name, this.arabic = '', BigInt? count, this.target = 0, this.round = 33, Map<String, int>? hist, BigInt? lifetime})
      : count = count ?? BigInt.zero,
        hist = hist ?? {},
        lifetime = lifetime ?? BigInt.zero;
  Map<String, dynamic> toJson() => {'id': id, 'n': name, 'a': arabic, 'c': count.toString(), 't': target, 'r': round, 'h': hist, 'l': lifetime.toString()};
  factory Counter.fromJson(Map<String, dynamic> j) => Counter(
        id: j['id'],
        name: j['n'] ?? '',
        arabic: j['a'] ?? '',
        count: BigInt.tryParse(j['c'] ?? '0') ?? BigInt.zero,
        target: j['t'] ?? 0,
        round: j['r'] ?? 33,
        hist: (j['h'] as Map?)?.map((k, v) => MapEntry(k as String, v as int)) ?? {},
        lifetime: BigInt.tryParse(j['l'] ?? '0') ?? BigInt.zero,
      );
}

String dayKey(DateTime d) => '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

class AppState extends ChangeNotifier {
  late SharedPreferences p;
  String lang = 'en';
  ThemeMode themeMode = ThemeMode.system;
  String method = 'karachi';
  int asr = 1;
  Map<String, int> adjust = {};
  double fontSize = 28;
  bool showEn = true, showUr = true;
  int preMin = 0;
  int hijriAdj = 0;
  bool vibrate = true;
  bool bigButton = false;
  Map<String, PrayerPref> prefs = {for (final k in kPrayerKeys) k: PrayerPref(sound: k == 'fajr' ? 'fajr' : 'classic')};
  Loc? loc;
  String locStatus = 'idle'; // idle | busy | denied | error | ok
  Map<String, List<int>> prayed = {};
  List<Counter> counters = [];
  String activeCounter = '';
  Set<String> quranMarks = {};
  Set<String> hadithMarks = {};
  Set<String> duaFavs = {};
  int lastSurah = 0, lastAyah = 0;
  final ValueNotifier<String?> azanPlaying = ValueNotifier(null);
  final ValueNotifier<int> clock = ValueNotifier(0);
  final ValueNotifier<int> tabNotifier = ValueNotifier(0);
  Map<String, List<int>> jamaah = {};
  List<int> qaza = [0, 0, 0, 0, 0];
  List<Map<String, dynamic>> customAlarms = [];
  bool tahajjud = false;

  String t(String k) => trLang(lang, k);
  bool get rtl => lang != 'en';
  String get uiFont => 'Poppins';

  Timer? _tick;
  Timer? _azanTimer;

  Future<void> init() async {
    p = await SharedPreferences.getInstance();
    lang = p.getString('lang') ?? 'en';
    themeMode = ThemeMode.values[(p.getInt('theme') ?? 0).clamp(0, 2) as int];
    method = p.getString('method') ?? 'karachi';
    asr = p.getInt('asr') ?? 1;
    fontSize = p.getDouble('font') ?? 28;
    showEn = p.getBool('showEn') ?? true;
    showUr = p.getBool('showUr') ?? true;
    preMin = p.getInt('preMin') ?? 0;
    hijriAdj = p.getInt('hijriAdj') ?? 0;
    vibrate = p.getBool('vibrate') ?? true;
    bigButton = p.getBool('bigButton') ?? false;
    lastSurah = p.getInt('lastSurah') ?? 0;
    lastAyah = p.getInt('lastAyah') ?? 0;
    activeCounter = p.getString('activeCounter') ?? '';
    quranMarks = (p.getStringList('quranMarks') ?? []).toSet();
    hadithMarks = (p.getStringList('hadithMarks') ?? []).toSet();
    duaFavs = (p.getStringList('duaFavs') ?? []).toSet();
    try {
      final a = p.getString('adjust');
      if (a != null) adjust = (jsonDecode(a) as Map).map((k, v) => MapEntry(k as String, v as int));
      final pf = p.getString('prefs');
      if (pf != null) {
        final m = jsonDecode(pf) as Map<String, dynamic>;
        for (final k in kPrayerKeys) {
          if (m[k] != null) prefs[k] = PrayerPref.fromJson(m[k]);
        }
      }
      final l = p.getString('loc');
      if (l != null) loc = Loc.fromJson(jsonDecode(l));
      final pr = p.getString('prayed');
      if (pr != null) prayed = (jsonDecode(pr) as Map).map((k, v) => MapEntry(k as String, (v as List).cast<int>()));
      final c = p.getString('counters');
      if (c != null) counters = (jsonDecode(c) as List).map((e) => Counter.fromJson(e)).toList();
      final ca = p.getString('customAlarms');
      if (ca != null) customAlarms = (jsonDecode(ca) as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
      tahajjud = p.getBool('tahajjud') ?? false;
    } catch (e) {
      debugPrint('state restore error: $e');
    }
    try {
      final j = p.getString('jamaah');
      if (j != null) jamaah = (jsonDecode(j) as Map).map((k, v) => MapEntry(k as String, (v as List).cast<int>()));
      final q = p.getStringList('qaza');
      if (q != null && q.length == 5) qaza = q.map(int.parse).toList();
    } catch (e) {
      debugPrint('tracker restore error: $e');
    }
    if (counters.isEmpty) {
      counters.add(Counter(id: 'c${DateTime.now().millisecondsSinceEpoch}', name: 'SubhanAllah', arabic: 'سُبْحَانَ اللَّهِ', target: 33, round: 33));
      activeCounter = counters.first.id;
    }
    if (!counters.any((c) => c.id == activeCounter)) activeCounter = counters.first.id;
    _tick = Timer.periodic(const Duration(seconds: 1), (_) => clock.value++);
    notifyListeners();
    // location + notifications are done after the first frame
    unawaited(refreshLocation(initial: true));
  }

  // ---------- persistence ----------
  void saveAll() {
    p.setString('lang', lang);
    p.setInt('theme', themeMode.index);
    p.setString('method', method);
    p.setInt('asr', asr);
    p.setDouble('font', fontSize);
    p.setBool('showEn', showEn);
    p.setBool('showUr', showUr);
    p.setInt('preMin', preMin);
    p.setInt('hijriAdj', hijriAdj);
    p.setBool('vibrate', vibrate);
    p.setBool('bigButton', bigButton);
    p.setString('adjust', jsonEncode(adjust));
    p.setString('prefs', jsonEncode(prefs.map((k, v) => MapEntry(k, v.toJson()))));
    if (loc != null) p.setString('loc', jsonEncode(loc!.toJson()));
    p.setStringList('quranMarks', quranMarks.toList());
    p.setStringList('hadithMarks', hadithMarks.toList());
    p.setStringList('duaFavs', duaFavs.toList());
    p.setString('customAlarms', jsonEncode(customAlarms));
    p.setBool('tahajjud', tahajjud);
  }

  Timer? _cDebounce;
  void saveCounters() {
    _cDebounce?.cancel();
    _cDebounce = Timer(const Duration(milliseconds: 400), () {
      p.setString('counters', jsonEncode(counters.map((e) => e.toJson()).toList()));
      p.setString('activeCounter', activeCounter);
    });
  }

  void update(void Function() fn, {bool reschedule = false}) {
    fn();
    saveAll();
    notifyListeners();
    if (reschedule) unawaited(rescheduleAzan());
  }

  // ---------- location ----------
  Future<void> refreshLocation({bool initial = false}) async {
    if (loc != null && !loc!.auto) {
      locStatus = 'ok';
      notifyListeners();
      await rescheduleAzan();
      return;
    }
    locStatus = 'busy';
    notifyListeners();
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        locStatus = loc == null ? 'error' : 'ok';
        notifyListeners();
        if (loc != null) await rescheduleAzan();
        return;
      }
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
        locStatus = loc == null ? 'denied' : 'ok';
        notifyListeners();
        if (loc != null) await rescheduleAzan();
        return;
      }
      Position? pos;
      try {
        pos = await Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.low, timeLimit: Duration(seconds: 20)));
      } catch (_) {
        pos = await Geolocator.getLastKnownPosition();
      }
      if (pos == null) {
        locStatus = loc == null ? 'error' : 'ok';
        notifyListeners();
        return;
      }
      final moved = loc == null || (loc!.lat - pos.latitude).abs() > 0.05 || (loc!.lng - pos.longitude).abs() > 0.05;
      String name = loc?.name ?? '';
      if (moved || name.isEmpty) name = await reverseGeocode(pos.latitude, pos.longitude) ?? '${pos.latitude.toStringAsFixed(2)}, ${pos.longitude.toStringAsFixed(2)}';
      loc = Loc(pos.latitude, pos.longitude, name, true, null);
      locStatus = 'ok';
      saveAll();
      notifyListeners();
      await rescheduleAzan();
    } catch (e) {
      debugPrint('location error: $e');
      locStatus = loc == null ? 'error' : 'ok';
      notifyListeners();
      if (loc != null) await rescheduleAzan();
    }
  }

  static Future<String?> reverseGeocode(double lat, double lng) async {
    try {
      final r = await http
          .get(Uri.parse('https://nominatim.openstreetmap.org/reverse?lat=$lat&lon=$lng&format=jsonv2&zoom=10&accept-language=en'), headers: {'User-Agent': 'OrbitIslam/1.0'})
          .timeout(const Duration(seconds: 8));
      if (r.statusCode != 200) return null;
      final a = (jsonDecode(r.body)['address'] ?? {}) as Map;
      final city = a['city'] ?? a['town'] ?? a['village'] ?? a['county'] ?? a['state'];
      final c = a['country'];
      if (city == null && c == null) return null;
      return [if (city != null) city, if (c != null) c].join(', ');
    } catch (_) {
      return null;
    }
  }

  static Future<List<Map<String, dynamic>>> searchCity(String q) async {
    final r = await http
        .get(Uri.parse('https://nominatim.openstreetmap.org/search?q=${Uri.encodeQueryComponent(q)}&format=jsonv2&limit=8&accept-language=en'), headers: {'User-Agent': 'OrbitIslam/1.0'})
        .timeout(const Duration(seconds: 10));
    final l = jsonDecode(r.body) as List;
    return l.map((e) => {'name': e['display_name'] as String, 'lat': double.parse(e['lat']), 'lng': double.parse(e['lon'])}).toList();
  }

  void setManualLocation(String name, double lat, double lng, int offsetMin) {
    loc = Loc(lat, lng, name, false, offsetMin);
    locStatus = 'ok';
    saveAll();
    notifyListeners();
    unawaited(rescheduleAzan());
  }

  void useGps() {
    loc = null;
    p.remove('loc');
    notifyListeners();
    unawaited(refreshLocation());
  }

  // ---------- prayer times ----------
  int offsetFor(DateTime d) {
    if (loc != null && !loc!.auto && loc!.offsetMin != null) return loc!.offsetMin!;
    return DateTime(d.year, d.month, d.day, 12).timeZoneOffset.inMinutes;
  }

  int get nowOffset => offsetFor(DateTime.now());

  /// Wall-clock "now" in the active location's time zone, as a UTC-flagged DateTime.
  DateTime get nowLoc => DateTime.now().toUtc().add(Duration(minutes: nowOffset));

  DayTimes? timesFor(DateTime date) {
    final l = loc;
    if (l == null) return null;
    return PrayerCalc.compute(
      date: DateTime(date.year, date.month, date.day),
      lat: l.lat,
      lng: l.lng,
      offsetMin: offsetFor(date),
      method: methodById(method),
      asrFactor: asr,
      adjust: adjust,
    );
  }

  DateTime _localDate() {
    final n = nowLoc;
    return DateTime(n.year, n.month, n.day);
  }

  DayTimes? get today => timesFor(_localDate());

  List<MapEntry<String, DateTime>> listFor(DayTimes t) => [
        MapEntry('fajr', t.fajr),
        MapEntry('dhuhr', t.dhuhr),
        MapEntry('asr', t.asr),
        MapEntry('maghrib', t.maghrib),
        MapEntry('isha', t.isha),
      ];

  /// Next prayer from now (UTC instants).
  MapEntry<String, DateTime>? get nextPrayer {
    final d = _localDate();
    final now = DateTime.now().toUtc();
    for (int i = 0; i < 3; i++) {
      final t = timesFor(d.add(Duration(days: i)));
      if (t == null) return null;
      for (final e in listFor(t)) {
        if (e.value.isAfter(now)) return e;
      }
    }
    return null;
  }

  String fmtTime(DateTime inst, {int? offset}) {
    final d = inst.add(Duration(minutes: offset ?? offsetFor(inst)));
    return '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
  }

  String fmtTime12(DateTime inst) {
    final d = inst.add(Duration(minutes: offsetFor(inst)));
    final h = d.hour % 12 == 0 ? 12 : d.hour % 12;
    return '$h:${d.minute.toString().padLeft(2, '0')} ${d.hour < 12 ? 'AM' : 'PM'}';
  }

  // ---------- tracker ----------
  List<int> prayedToday() => prayed[dayKey(nowLoc)] ?? [];
  void togglePrayed(int i) {
    final k = dayKey(nowLoc);
    final l = List<int>.from(prayed[k] ?? []);
    l.contains(i) ? l.remove(i) : l.add(i);
    prayed[k] = l;
    if (prayed.length > 400) {
      final keys = prayed.keys.toList()..sort();
      for (final x in keys.take(prayed.length - 400)) {
        prayed.remove(x);
      }
    }
    p.setString('prayed', jsonEncode(prayed));
    HapticFeedback.selectionClick();
    notifyListeners();
  }

  void toggleJamaah(int i) {
    final k = dayKey(nowLoc);
    final l = List<int>.from(jamaah[k] ?? []);
    l.contains(i) ? l.remove(i) : l.add(i);
    jamaah[k] = l;
    p.setString('jamaah', jsonEncode(jamaah));
    notifyListeners();
  }

  void changeQaza(int i, int by) {
    qaza[i] = (qaza[i] + by).clamp(0, 9999) as int;
    p.setStringList('qaza', qaza.map((e) => '$e').toList());
    notifyListeners();
  }

  // ---------- azan scheduling ----------
  Future<void> rescheduleAzan() async {
    await NotifService.instance.scheduleAll(this);
    _armWebTimer();
  }

  void _armWebTimer() {
    _azanTimer?.cancel();
    if (!kIsWeb) return;
    final n = nextPrayer;
    if (n == null) return;
    final pref = prefs[n.key]!;
    final delay = n.value.difference(DateTime.now().toUtc());
    _azanTimer = Timer(delay.isNegative ? Duration.zero : delay, () async {
      if (pref.enabled && pref.mode != 'silent') {
        azanPlaying.value = n.key;
        await AzanPlayer.instance.play(pref.sound);
      }
      Timer(const Duration(seconds: 2), _armWebTimer);
    });
  }

  Future<void> stopAzan() async {
    await AzanPlayer.instance.stop();
    azanPlaying.value = null;
  }

  // ---------- hijri ----------
  static const hijriMonths = ['Muharram', 'Safar', "Rabi' al-awwal", "Rabi' al-thani", 'Jumada al-awwal', 'Jumada al-thani', 'Rajab', "Sha'ban", 'Ramadan', 'Shawwal', "Dhu al-Qi'dah", 'Dhu al-Hijjah'];
  static const hijriMonthsAr = ['محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر', 'جمادى الأولى', 'جمادى الآخرة', 'رجب', 'شعبان', 'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة'];

  @override
  void dispose() {
    _tick?.cancel();
    _azanTimer?.cancel();
    super.dispose();
  }
}

final AppState app = AppState();
