import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:just_audio/just_audio.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import 'state.dart';

// ======================= Azan player (in-app) =======================
class AzanPlayer {
  AzanPlayer._();
  static final AzanPlayer instance = AzanPlayer._();
  final AudioPlayer _p = AudioPlayer();
  String? current;

  Future<void> play(String sound) async {
    try {
      await _p.stop();
      current = sound;
      await _p.setAsset('assets/azan/azan_$sound.mp3');
      await _p.play();
    } catch (e) {
      debugPrint('azan play error: $e');
    }
  }

  Future<void> stop() async {
    current = null;
    try {
      await _p.stop();
    } catch (_) {}
  }

  Stream<bool> get playing => _p.playingStream;
}

// ======================= Notifications / azan alarms =======================
class NotifService {
  NotifService._();
  static final NotifService instance = NotifService._();
  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  bool _ready = false;

  bool get _supported => !kIsWeb && (defaultTargetPlatform == TargetPlatform.android || defaultTargetPlatform == TargetPlatform.iOS);

  Future<void> init() async {
    if (!_supported || _ready) return;
    tzdata.initializeTimeZones();
    const init = InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      iOS: DarwinInitializationSettings(requestAlertPermission: false, requestBadgePermission: false, requestSoundPermission: false),
    );
    await _plugin.initialize(init);
    final a = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    if (a != null) {
      for (final s in kSounds) {
        await a.createNotificationChannel(AndroidNotificationChannel(
          'azan_$s',
          'Azan - ${kSoundNames[s]}',
          description: 'Plays the azan at prayer time',
          importance: Importance.max,
          sound: RawResourceAndroidNotificationSound('azan_$s'),
          playSound: true,
          enableVibration: true,
          audioAttributesUsage: AudioAttributesUsage.alarm,
        ));
      }
      await a.createNotificationChannel(const AndroidNotificationChannel('azan_notify', 'Prayer time (notification sound)', importance: Importance.high));
      await a.createNotificationChannel(const AndroidNotificationChannel('azan_silent', 'Prayer time (silent)', importance: Importance.defaultImportance, playSound: false, enableVibration: false));
      await a.createNotificationChannel(const AndroidNotificationChannel('azan_reminder', 'Reminder before prayer', importance: Importance.high));
    }
    _ready = true;
  }

  Future<bool> requestPermissions() async {
    if (!_supported) return true;
    await init();
    bool ok = true;
    final a = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    if (a != null) {
      ok = (await a.requestNotificationsPermission()) ?? true;
      try {
        await a.requestExactAlarmsPermission();
      } catch (_) {}
    }
    final i = _plugin.resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>();
    if (i != null) ok = (await i.requestPermissions(alert: true, badge: true, sound: true)) ?? false;
    return ok;
  }

  NotificationDetails _details(PrayerPref pref, {bool reminder = false}) {
    String channel;
    if (reminder) {
      channel = 'azan_reminder';
    } else if (pref.mode == 'azan') {
      channel = 'azan_${pref.sound}';
    } else if (pref.mode == 'notify') {
      channel = 'azan_notify';
    } else {
      channel = 'azan_silent';
    }
    final android = AndroidNotificationDetails(
      channel,
      channel,
      importance: Importance.max,
      priority: Priority.high,
      category: reminder ? AndroidNotificationCategory.reminder : AndroidNotificationCategory.alarm,
      playSound: reminder || pref.mode != 'silent',
      sound: (!reminder && pref.mode == 'azan') ? RawResourceAndroidNotificationSound('azan_${pref.sound}') : null,
      audioAttributesUsage: (!reminder && pref.mode == 'azan') ? AudioAttributesUsage.alarm : AudioAttributesUsage.notification,
    );
    final ios = DarwinNotificationDetails(
      presentAlert: true,
      presentSound: reminder || pref.mode != 'silent',
      sound: (!reminder && pref.mode == 'azan') ? 'azan_${pref.sound}.aiff' : null,
      interruptionLevel: InterruptionLevel.timeSensitive,
    );
    return NotificationDetails(android: android, iOS: ios);
  }

  /// Cancels everything and schedules the next 7 days of azan alarms for the current location.
  Future<void> scheduleAll(AppState s) async {
    if (!_supported) return;
    try {
      await init();
      await _plugin.cancelAll();
      if (s.loc == null) return;
      final now = DateTime.now().toUtc();
      final base = s.nowLoc;
      var id = 100;
      for (int day = 0; day < 7; day++) {
        final d = DateTime(base.year, base.month, base.day).add(Duration(days: day));
        final times = s.timesFor(d);
        if (times == null) continue;
        for (final e in s.listFor(times)) {
          final pref = s.prefs[e.key]!;
          if (!pref.enabled) continue;
          final when = e.value;
          final title = '${s.t(e.key)}  ${s.fmtTime(when)}';
          final body = s.loc!.name;
          if (when.isAfter(now)) {
            await _schedule(id++, title, body, when, _details(pref));
          }
          if (s.preMin > 0) {
            final pre = when.subtract(Duration(minutes: s.preMin));
            if (pre.isAfter(now)) {
              await _schedule(id++, '${s.t(e.key)} ${s.t('in')} ${s.preMin} ${s.t('minutes')}', body, pre, _details(pref, reminder: true));
            }
          }
        }
      }
    } catch (e) {
      debugPrint('schedule error: $e');
    }
  }

  Future<void> _schedule(int id, String title, String body, DateTime utc, NotificationDetails d) async {
    final when = tz.TZDateTime.from(utc, tz.UTC);
    try {
      await _plugin.zonedSchedule(id, title, body, when, d,
          androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle, uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime);
    } catch (_) {
      // exact alarms not permitted: fall back to inexact
      await _plugin.zonedSchedule(id, title, body, when, d,
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle, uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime);
    }
  }
}

// ======================= Data repository (offline assets) =======================
dynamic _decodeJson(String s) => jsonDecode(s);

class Surah {
  final int n;
  final String name, en, ar, place;
  final List<List<dynamic>> a; // [ar, en, ur, juz, sajda]
  Surah(this.n, this.name, this.en, this.ar, this.place, this.a);
}

class HCollection {
  final String key, name, ar;
  final Map<String, String> sections;
  final List<List<dynamic>> h; // [num, sectionId, ar, en, ur, grade]
  HCollection(this.key, this.name, this.ar, this.sections, this.h);
}

const List<List<String>> kHadithBooks = [
  ['bukhari', 'Sahih al-Bukhari', 'صحيح البخاري'],
  ['muslim', 'Sahih Muslim', 'صحيح مسلم'],
  ['ibnmajah', 'Sunan Ibn Majah', 'سنن ابن ماجه'],
  ['malik', 'Muwatta Malik', 'موطأ مالك'],
  ['nawawi', '40 Hadith of an-Nawawi', 'الأربعون النووية'],
  ['qudsi', '40 Hadith Qudsi', 'الأربعون القدسية'],
];

class Repo {
  static List<Surah>? _quran;
  static List<int>? _cum; // cumulative ayah counts for global numbering
  static final Map<String, HCollection> _h = {};
  static List<dynamic>? _duas;

  static Future<List<Surah>> quran() async {
    if (_quran != null) return _quran!;
    final s = await rootBundle.loadString('assets/data/quran.json');
    final j = await compute(_decodeJson, s) as Map;
    _quran = (j['surahs'] as List)
        .map((e) => Surah(e['n'], e['name'], e['en'], e['ar'], e['place'], (e['a'] as List).map((x) => (x as List).cast<dynamic>()).toList()))
        .toList();
    int c = 0;
    _cum = [for (final su in _quran!) c += su.a.length];
    return _quran!;
  }

  /// Global ayah number (1..6236) for audio CDN.
  static int globalAyah(int surah, int ayah) => (surah == 1 ? 0 : _cum![surah - 2]) + ayah;

  static Future<HCollection> hadith(String key) async {
    if (_h.containsKey(key)) return _h[key]!;
    final s = await rootBundle.loadString('assets/data/h_$key.json');
    final j = await compute(_decodeJson, s) as Map;
    final c = HCollection(
      key,
      j['name'],
      j['ar'],
      (j['sections'] as Map).map((k, v) => MapEntry(k as String, v as String)),
      (j['h'] as List).map((x) => (x as List).cast<dynamic>()).toList(),
    );
    _h[key] = c;
    return c;
  }

  static Future<List<dynamic>> duas() async {
    if (_duas != null) return _duas!;
    final s = await rootBundle.loadString('assets/data/duas.json');
    _duas = jsonDecode(s) as List;
    return _duas!;
  }
}
