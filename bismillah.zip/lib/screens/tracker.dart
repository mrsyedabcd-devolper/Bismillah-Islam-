import 'package:flutter/material.dart';
import '../state.dart';
import '../widgets.dart';
import '../theme.dart';

class TrackerScreen extends StatefulWidget {
  const TrackerScreen({super.key});
  @override
  State<TrackerScreen> createState() => _TrackerScreenState();
}

class _TrackerScreenState extends State<TrackerScreen> {
  int perDay = 1;

  static const names = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];

  /// Days in the last 7 (including today) and how many of the 5 prayers were done each day.
  List<int> weekCounts() {
    final n = app.nowLoc;
    final out = <int>[];
    for (int i = 6; i >= 0; i--) {
      final d = DateTime(n.year, n.month, n.day).subtract(Duration(days: i));
      out.add((app.prayed[dayKey(d)] ?? []).length);
    }
    return out;
  }

  /// Consecutive days, ending today, with all 5 prayers done.
  int streak() {
    final n = app.nowLoc;
    int s = 0;
    for (int i = 0; i < 400; i++) {
      final d = DateTime(n.year, n.month, n.day).subtract(Duration(days: i));
      final c = (app.prayed[dayKey(d)] ?? []).length;
      if (c == 5) {
        s++;
      } else if (i == 0) {
        continue; // today not finished yet, does not break the streak
      } else {
        break;
      }
    }
    return s;
  }

  @override
  Widget build(BuildContext context) {
    final p = pal(context);
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final done = app.prayedToday();
        final jam = app.jamaah[dayKey(app.nowLoc)] ?? [];
        final week = weekCounts();
        final total7 = week.fold<int>(0, (a, b) => a + b);
        final qazaTotal = app.qaza.fold<int>(0, (a, b) => a + b);
        final days = (qazaTotal / perDay).ceil();
        return AppPage(
          title: app.t('prayer_tracker_title'),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
            children: [
              AppCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(app.t('today'), style: TextStyle(fontWeight: FontWeight.w700, color: p.primary)),
                  const SizedBox(height: 8),
                  for (int i = 0; i < 5; i++)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Row(children: [
                        Expanded(child: Text(app.t(names[i]), style: const TextStyle(fontWeight: FontWeight.w600))),
                        Pill(app.t('jamaah'), on: jam.contains(i), onTap: () => app.toggleJamaah(i)),
                        const SizedBox(width: 8),
                        Checkbox(value: done.contains(i), activeColor: p.primary, onChanged: (_) => app.togglePrayed(i)),
                      ]),
                    ),
                ]),
              ),
              const SizedBox(height: 12),
              AppCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(app.t('last7'), style: TextStyle(fontWeight: FontWeight.w700, color: p.primary)),
                  const SizedBox(height: 10),
                  Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                    for (final c in week)
                      Expanded(
                        child: Column(children: [
                          Text('$c', style: TextStyle(fontSize: 11, color: p.muted)),
                          const SizedBox(height: 4),
                          Container(height: 6 + 50 * c / 5, margin: const EdgeInsets.symmetric(horizontal: 5), decoration: BoxDecoration(color: c == 5 ? OC.green : p.primary.withOpacity(.4), borderRadius: BorderRadius.circular(6))),
                        ]),
                      ),
                  ]),
                  const SizedBox(height: 12),
                  Text('${app.t('done')}: $total7 / 35 · ${app.t('streak')}: ${streak()}', style: const TextStyle(fontWeight: FontWeight.w600)),
                ]),
              ),
              const SizedBox(height: 12),
              AppCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(app.t('qaza'), style: TextStyle(fontWeight: FontWeight.w700, color: p.primary)),
                  Text(app.t('qaza_note'), style: TextStyle(fontSize: 12, color: p.muted)),
                  const SizedBox(height: 8),
                  for (int i = 0; i < 5; i++)
                    Row(children: [
                      Expanded(child: Text(app.t(names[i]))),
                      IconButton(visualDensity: VisualDensity.compact, icon: const Icon(Icons.remove_circle_outline_rounded), onPressed: () => app.changeQaza(i, -1)),
                      SizedBox(width: 36, child: Text('${app.qaza[i]}', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700))),
                      IconButton(visualDensity: VisualDensity.compact, icon: const Icon(Icons.add_circle_outline_rounded), onPressed: () => app.changeQaza(i, 1)),
                    ]),
                  const Divider(),
                  Row(children: [
                    Expanded(child: Text(app.t('qaza_per_day'))),
                    for (final v in [1, 2, 3])
                      Padding(padding: const EdgeInsets.only(left: 6), child: Pill('$v', on: perDay == v, onTap: () => setState(() => perDay = v))),
                  ]),
                  const SizedBox(height: 6),
                  Text(qazaTotal == 0 ? app.t('qaza_none') : '${app.t('qaza_plan')}: $qazaTotal → $days ${app.t('days')}', style: const TextStyle(fontWeight: FontWeight.w600)),
                ]),
              ),
              const SizedBox(height: 12),
              Text(app.t('tracker_source'), style: TextStyle(fontSize: 11, color: p.muted)),
            ],
          ),
        );
      },
    );
  }
}
