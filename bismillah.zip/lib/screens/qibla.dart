import 'dart:math' as math;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_compass/flutter_compass.dart';
import '../prayer_calc.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

class QiblaScreen extends StatefulWidget {
  const QiblaScreen({super.key});
  @override
  State<QiblaScreen> createState() => _QiblaScreenState();
}

class _QiblaScreenState extends State<QiblaScreen> {
  bool wasAligned = false;

  @override
  Widget build(BuildContext context) {
    final p = pal(context);
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final l = app.loc;
        if (l == null) return Center(child: Text(app.t('detecting'), style: TextStyle(color: p.muted)));
        final bearing = PrayerCalc.qiblaBearing(l.lat, l.lng);
        final dist = PrayerCalc.distanceToKaabaKm(l.lat, l.lng);
        final stream = kIsWeb ? null : FlutterCompass.events;
        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
          children: [
            Text(app.t('qibla'), style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w700)),
            const SizedBox(height: 16),
            StreamBuilder<CompassEvent>(
              stream: stream,
              builder: (context, snap) {
                final heading = snap.data?.heading;
                final has = heading != null;
                final h = heading ?? 0.0;
                var diff = ((bearing - h) % 360 + 360) % 360;
                if (diff > 180) diff -= 360;
                final aligned = has && diff.abs() < 3;
                if (aligned && !wasAligned && app.vibrate) HapticFeedback.mediumImpact();
                wasAligned = aligned;
                return Column(children: [
                  SizedBox(
                    width: 300,
                    height: 300,
                    child: CustomPaint(painter: _DialPainter(heading: h, bearing: bearing, p: p, aligned: aligned)),
                  ),
                  const SizedBox(height: 12),
                  Text(has ? (aligned ? app.t('aligned') : '${diff.abs().round()}° ${diff > 0 ? '→' : '←'}') : app.t('compass_na'),
                      textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w600, color: aligned ? OC_GREEN : p.text)),
                  if (has) Padding(padding: const EdgeInsets.only(top: 4), child: Text(app.t('calibrate'), textAlign: TextAlign.center, style: TextStyle(fontSize: 11.5, color: p.muted))),
                ]);
              },
            ),
            const SizedBox(height: 18),
            Row(children: [
              Expanded(child: _info(context, app.t('qibla_dir'), '${bearing.toStringAsFixed(1)}°')),
              const SizedBox(width: 10),
              Expanded(child: _info(context, app.t('distance'), '${dist.round()} km')),
            ]),
            const SizedBox(height: 10),
            AppCard(child: Row(children: [Icon(Icons.location_on_rounded, color: p.primary), const SizedBox(width: 8), Expanded(child: Text(l.name))])),
          ],
        );
      },
    );
  }

  Widget _info(BuildContext c, String label, String value) {
    final p = pal(c);
    return AppCard(child: Column(children: [Text(value, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: p.primary)), const SizedBox(height: 2), Text(label, textAlign: TextAlign.center, style: TextStyle(fontSize: 11.5, color: p.muted))]));
  }
}

const Color OC_GREEN = Color(0xFF3BAA6E);

class _DialPainter extends CustomPainter {
  final double heading, bearing;
  final Pal p;
  final bool aligned;
  _DialPainter({required this.heading, required this.bearing, required this.p, required this.aligned});

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2 - 6;
    canvas.drawCircle(c, r, Paint()..color = p.surface);
    canvas.drawCircle(c, r, Paint()..color = (aligned ? OC_GREEN : p.border)..style = PaintingStyle.stroke..strokeWidth = aligned ? 5 : 3);
    // rotating dial (north up when heading = 0)
    canvas.save();
    canvas.translate(c.dx, c.dy);
    canvas.rotate(-heading * math.pi / 180);
    for (int i = 0; i < 72; i++) {
      final a = i * 5 * math.pi / 180;
      final major = i % 9 == 0;
      final len = major ? 14.0 : 7.0;
      final p1 = Offset(math.sin(a) * (r - 4), -math.cos(a) * (r - 4));
      final p2 = Offset(math.sin(a) * (r - 4 - len), -math.cos(a) * (r - 4 - len));
      canvas.drawLine(p1, p2, Paint()..color = (major ? p.muted : p.border)..strokeWidth = major ? 2 : 1);
    }
    void label(String s, double deg, Color col) {
      final tp = TextPainter(text: TextSpan(text: s, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: col)), textDirection: TextDirection.ltr)..layout();
      final a = deg * math.pi / 180;
      final o = Offset(math.sin(a) * (r - 34), -math.cos(a) * (r - 34));
      canvas.save();
      canvas.translate(o.dx, o.dy);
      canvas.rotate(heading * math.pi / 180);
      tp.paint(canvas, Offset(-tp.width / 2, -tp.height / 2));
      canvas.restore();
    }
    label('N', 0, p.primary);
    label('E', 90, p.muted);
    label('S', 180, p.muted);
    label('W', 270, p.muted);
    // qibla marker on the dial
    final qa = bearing * math.pi / 180;
    final qo = Offset(math.sin(qa) * (r - 62), -math.cos(qa) * (r - 62));
    canvas.drawLine(Offset.zero, qo, Paint()..color = p.gold..strokeWidth = 3..strokeCap = StrokeCap.round);
    canvas.drawCircle(qo, 20, Paint()..color = p.gold);
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: qo, width: 18, height: 18), const Radius.circular(3)), Paint()..color = const Color(0xFF1B1209));
    canvas.drawRect(Rect.fromCenter(center: qo.translate(0, -3), width: 18, height: 3), Paint()..color = p.gold);
    canvas.restore();
    // fixed phone-top pointer
    final path = Path()
      ..moveTo(c.dx, c.dy - r + 2)
      ..lineTo(c.dx - 9, c.dy - r + 22)
      ..lineTo(c.dx + 9, c.dy - r + 22)
      ..close();
    canvas.drawPath(path, Paint()..color = p.primary);
    canvas.drawCircle(c, 6, Paint()..color = p.primary);
  }

  @override
  bool shouldRepaint(covariant _DialPainter o) => o.heading != heading || o.bearing != bearing || o.aligned != aligned || o.p != p;
}
