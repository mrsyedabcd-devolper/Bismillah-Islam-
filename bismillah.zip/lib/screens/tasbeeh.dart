import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../state.dart';
import '../widgets.dart';

const List<List<dynamic>> kPresets = [
  ['SubhanAllah', 'سُبْحَانَ اللَّهِ', 33, 33],
  ['Alhamdulillah', 'الْحَمْدُ لِلَّهِ', 33, 33],
  ['Allahu Akbar', 'اللَّهُ أَكْبَرُ', 34, 34],
  ['La ilaha illallah', 'لَا إِلَٰهَ إِلَّا اللَّهُ', 100, 100],
  ['Astaghfirullah', 'أَسْتَغْفِرُ اللَّهَ', 100, 100],
  ['Salawat', 'اللَّهُمَّ صَلِّ عَلَىٰ مُحَمَّدٍ', 100, 100],
  ['SubhanAllahi wa bihamdihi', 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ', 100, 100],
  ['La hawla wa la quwwata illa billah', 'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ', 100, 100],
];

class TasbeehScreen extends StatefulWidget {
  const TasbeehScreen({super.key});
  @override
  State<TasbeehScreen> createState() => _TasbeehScreenState();
}

class _TasbeehScreenState extends State<TasbeehScreen> {
  Counter get cur => app.counters.firstWhere((c) => c.id == app.activeCounter, orElse: () => app.counters.first);

  void tap() {
    final c = cur;
    c.count += BigInt.one;
    c.lifetime += BigInt.one;
    final k = dayKey(app.nowLoc);
    c.hist[k] = (c.hist[k] ?? 0) + 1;
    if (c.hist.length > 120) {
      final keys = c.hist.keys.toList()..sort();
      for (final x in keys.take(c.hist.length - 120)) {
        c.hist.remove(x);
      }
    }
    if (app.vibrate) {
      final unit = c.target > 0 ? c.target : c.round;
      if (unit > 0 && c.count % BigInt.from(unit) == BigInt.zero) {
        HapticFeedback.heavyImpact();
      } else {
        HapticFeedback.selectionClick();
      }
    }
    app.saveCounters();
    setState(() {});
  }

  void undo() {
    final c = cur;
    if (c.count == BigInt.zero) return;
    c.count -= BigInt.one;
    c.lifetime -= BigInt.one;
    final k = dayKey(app.nowLoc);
    if ((c.hist[k] ?? 0) > 0) c.hist[k] = c.hist[k]! - 1;
    app.saveCounters();
    setState(() {});
  }

  Future<void> reset() async {
    if (!await _ask(app.t('reset'))) return;
    cur.count = BigInt.zero;
    app.saveCounters();
    setState(() {});
  }

  Future<bool> _ask(String what) async =>
      (await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          title: Text(what),
          content: Text(app.t('are_you_sure')),
          actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: Text(app.t('cancel'))), TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('OK'))],
        ),
      )) ??
      false;

  Future<void> edit({Counter? existing, List<dynamic>? preset}) async {
    final name = TextEditingController(text: existing?.name ?? preset?[0] ?? '');
    final ar = TextEditingController(text: existing?.arabic ?? preset?[1] ?? '');
    final target = TextEditingController(text: '${existing?.target ?? preset?[2] ?? 0}');
    final round = TextEditingController(text: '${existing?.round ?? preset?[3] ?? 33}');
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Text(existing == null ? app.t('add_counter') : app.t('name')),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: name, decoration: InputDecoration(labelText: app.t('name'))),
            const SizedBox(height: 10),
            TextField(controller: ar, textDirection: TextDirection.rtl, style: const TextStyle(fontFamily: 'Amiri', fontSize: 20), decoration: const InputDecoration(labelText: 'العربية')),
            const SizedBox(height: 10),
            TextField(controller: target, keyboardType: TextInputType.number, inputFormatters: [FilteringTextInputFormatter.digitsOnly], decoration: InputDecoration(labelText: app.t('target'))),
            const SizedBox(height: 10),
            TextField(controller: round, keyboardType: TextInputType.number, inputFormatters: [FilteringTextInputFormatter.digitsOnly], decoration: InputDecoration(labelText: app.t('round_size'))),
          ]),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: Text(app.t('cancel'))), FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(app.t('save')))],
      ),
    );
    if (ok != true) return;
    final tg = int.tryParse(target.text) ?? 0, rd = int.tryParse(round.text) ?? 0;
    final nm = name.text.trim().isEmpty ? 'Counter' : name.text.trim();
    if (existing != null) {
      existing.name = nm;
      existing.arabic = ar.text.trim();
      existing.target = tg;
      existing.round = rd;
    } else {
      final c = Counter(id: 'c${DateTime.now().microsecondsSinceEpoch}', name: nm, arabic: ar.text.trim(), target: tg, round: rd);
      app.counters.add(c);
      app.activeCounter = c.id;
    }
    app.saveCounters();
    setState(() {});
  }

  Future<void> remove() async {
    if (app.counters.length <= 1) return;
    if (!await confirm(context, '${cur.name}?')) return;
    app.counters.removeWhere((c) => c.id == cur.id);
    app.activeCounter = app.counters.first.id;
    app.saveCounters();
    setState(() {});
  }

  int sumDays(Counter c, int days) {
    int s = 0;
    final n = app.nowLoc;
    for (int i = 0; i < days; i++) {
      s += c.hist[dayKey(DateTime(n.year, n.month, n.day).subtract(Duration(days: i)))] ?? 0;
    }
    return s;
  }

  @override
  Widget build(BuildContext context) {
    final p = pal(context);
    final c = cur;
    final unit = c.target > 0 ? c.target : (c.round > 0 ? c.round : 0);
    final inRound = unit > 0 ? (c.count % BigInt.from(unit)).toInt() : 0;
    final progress = unit > 0 ? (inRound == 0 && c.count > BigInt.zero ? 1.0 : inRound / unit) : 0.0;
    final rounds = unit > 0 ? (c.count ~/ BigInt.from(unit)).toString() : '0';
    final today = c.hist[dayKey(app.nowLoc)] ?? 0;
    final size = app.bigButton ? 300.0 : 250.0;
    final n = app.nowLoc;
    final days = [for (int i = 6; i >= 0; i--) c.hist[dayKey(DateTime(n.year, n.month, n.day).subtract(Duration(days: i)))] ?? 0];
    final maxDay = days.fold<int>(1, math.max);
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
      children: [
        Row(children: [
          Expanded(child: Text(app.t('tasbeeh'), style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w700))),
          IconButton(
            tooltip: app.t('vibration'),
            icon: Icon(app.vibrate ? Icons.vibration_rounded : Icons.phone_android_rounded, color: p.primary),
            onPressed: () => app.update(() => app.vibrate = !app.vibrate),
          ),
          IconButton(tooltip: app.t('keep_awake'), icon: Icon(app.bigButton ? Icons.zoom_out_map_rounded : Icons.zoom_in_map_rounded, color: p.primary), onPressed: () => app.update(() => app.bigButton = !app.bigButton)),
        ]),
        SizedBox(
          height: 42,
          child: ListView(scrollDirection: Axis.horizontal, children: [
            for (final x in app.counters)
              Padding(padding: const EdgeInsets.only(right: 8), child: Pill(x.name, on: x.id == c.id, onTap: () => setState(() => app.activeCounter = x.id))),
            Pill('+ ${app.t('add_counter')}', onTap: () => edit()),
            const SizedBox(width: 8),
            Pill(app.t('preset'), onTap: () => showSheet(context, app.t('preset'), ListView(shrinkWrap: true, children: [
                  for (final pr in kPresets)
                    ListTile(
                      title: Text(pr[0]),
                      trailing: Text(pr[1], style: const TextStyle(fontFamily: 'Amiri', fontSize: 20)),
                      onTap: () {
                        Navigator.pop(context);
                        edit(preset: pr);
                      },
                    ),
                ]))),
          ]),
        ),
        const SizedBox(height: 14),
        if (c.arabic.isNotEmpty) ArabicText(c.arabic, size: 30, align: TextAlign.center, color: p.primary),
        Center(child: Text(c.name, style: TextStyle(color: p.muted, fontWeight: FontWeight.w500))),
        const SizedBox(height: 10),
        Center(
          child: GestureDetector(
            onTap: tap,
            child: SizedBox(
              width: size,
              height: size,
              child: CustomPaint(
                painter: _RingPainter(progress: progress, track: p.border, color: p.primary, gold: p.gold),
                child: Center(
                  child: Container(
                    width: size - 40,
                    height: size - 40,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(colors: p.hero, begin: Alignment.topLeft, end: Alignment.bottomRight),
                      boxShadow: [BoxShadow(color: p.primary.withOpacity(.35), blurRadius: 26, offset: const Offset(0, 12))],
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        FittedBox(fit: BoxFit.scaleDown, child: Text(c.count.toString(), style: const TextStyle(color: Colors.white, fontSize: 64, fontWeight: FontWeight.w700, height: 1.1))),
                        if (unit > 0) Text('$inRound / $unit', style: TextStyle(color: Colors.white.withOpacity(.85), fontSize: 14)),
                        if (c.target == 0 && c.round == 0) Text('∞', style: TextStyle(color: Colors.white.withOpacity(.85), fontSize: 20)),
                      ]),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 14),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          OutlinedButton.icon(onPressed: undo, icon: const Icon(Icons.undo_rounded, size: 18), label: Text(app.t('undo'))),
          const SizedBox(width: 8),
          OutlinedButton.icon(onPressed: reset, icon: const Icon(Icons.restart_alt_rounded, size: 18), label: Text(app.t('reset'))),
          const SizedBox(width: 8),
          IconButton(onPressed: () => edit(existing: c), icon: Icon(Icons.edit_rounded, color: p.primary)),
          IconButton(onPressed: app.counters.length > 1 ? remove : null, icon: Icon(Icons.delete_outline_rounded, color: p.muted)),
        ]),
        const SizedBox(height: 14),
        Row(children: [
          _stat(context, app.t('today'), '$today'),
          _stat(context, app.t('rounds'), rounds),
          _stat(context, app.t('total'), c.lifetime.toString()),
        ]),
        const SizedBox(height: 14),
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${app.t('last7')} · ${sumDays(c, 7)}', style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            SizedBox(
              height: 90,
              child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                for (int i = 0; i < 7; i++)
                  Expanded(
                    child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                      Text(days[i] == 0 ? '' : '${days[i]}', style: TextStyle(fontSize: 9, color: p.muted)),
                      const SizedBox(height: 2),
                      Container(
                        margin: const EdgeInsets.symmetric(horizontal: 6),
                        height: math.max(4, 60 * days[i] / maxDay),
                        decoration: BoxDecoration(color: i == 6 ? p.primary : p.primary.withOpacity(.35), borderRadius: BorderRadius.circular(6)),
                      ),
                    ]),
                  ),
              ]),
            ),
          ]),
        ),
      ],
    );
  }

  Widget _stat(BuildContext context, String label, String value) {
    final p = pal(context);
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4),
        child: AppCard(
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
          child: Column(children: [
            FittedBox(fit: BoxFit.scaleDown, child: Text(value, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: p.primary))),
            Text(label, style: TextStyle(fontSize: 11, color: p.muted)),
          ]),
        ),
      ),
    );
  }
}

class _RingPainter extends CustomPainter {
  final double progress;
  final Color track, color, gold;
  _RingPainter({required this.progress, required this.track, required this.color, required this.gold});
  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2 - 8;
    final bg = Paint()
      ..color = track
      ..style = PaintingStyle.stroke
      ..strokeWidth = 9;
    canvas.drawCircle(c, r, bg);
    final fg = Paint()
      ..color = gold
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 9;
    canvas.drawArc(Rect.fromCircle(center: c, radius: r), -math.pi / 2, 2 * math.pi * progress, false, fg);
  }

  @override
  bool shouldRepaint(covariant _RingPainter o) => o.progress != progress || o.color != color;
}
