import 'package:flutter/material.dart';
import '../hijri.dart';
import '../state.dart';
import '../widgets.dart';
import 'calendar_data.dart';

class _Upcoming {
  final DateTime date;
  final String title, note;
  final String? source;
  final bool disputed;
  _Upcoming(this.date, this.title, this.note, this.source, this.disputed);
}

class CalendarScreen extends StatelessWidget {
  const CalendarScreen({super.key});

  static const _mo = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  static String fmt(DateTime d) => '${d.day} ${_mo[d.month - 1]} ${d.year}';

  /// Next Gregorian date of a Hijri month/day, on or after today (in the user's location).
  static DateTime nextOccurrence(int hm, int hd, int todayJdn, HDate today) {
    var y = today.y;
    var j = hToJdn(y, hm, hd);
    if (j < todayJdn) j = hToJdn(y + 1, hm, hd);
    return jdnToG(j);
  }

  List<_Upcoming> upcoming(int todayJdn, HDate today) {
    final out = <_Upcoming>[];
    for (final e in kEvents) {
      out.add(_Upcoming(nextOccurrence(e.m, e.d, todayJdn, today), e.title, e.note, e.source, e.disputed));
    }
    // weekly and monthly recurring fasts
    out.add(_Upcoming(_nextWeekday(DateTime.now(), DateTime.monday), 'Fast on Monday (sunnah)', 'Voluntary fast on Monday and Thursday.', kRecurring[1]['source'], false));
    out.add(_Upcoming(_nextWeekday(DateTime.now(), DateTime.thursday), 'Fast on Thursday (sunnah)', 'Voluntary fast on Monday and Thursday.', kRecurring[1]['source'], false));
    // white days: 13, 14, 15 of the current Hijri month
    final cur = today;
    final wd = [13, 14, 15].map((d) => hToJdn(cur.y, cur.m, d)).firstWhere((j) => j >= todayJdn, orElse: () => hToJdn(cur.m == 12 ? cur.y + 1 : cur.y, cur.m == 12 ? 1 : cur.m + 1, 13));
    out.add(_Upcoming(jdnToG(wd), 'White days (13-15 of each month)', 'Voluntary fasting on the 13th, 14th and 15th.', kRecurring[0]['source'], false));
    out.sort((a, b) => a.date.compareTo(b.date));
    return out;
  }

  static DateTime _nextWeekday(DateTime now, int wd) {
    var d = DateTime(now.year, now.month, now.day);
    while (d.weekday != wd) {
      d = d.add(const Duration(days: 1));
    }
    return d;
  }

  @override
  Widget build(BuildContext context) {
    final p = pal(context);
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final n = app.nowLoc.add(Duration(days: app.hijriAdj));
        final todayG = DateTime(n.year, n.month, n.day);
        final jdn = gToJdn(todayG);
        final today = hFromJdn(jdn);
        final list = upcoming(jdn, today);
        final mon = app.lang == 'ar' ? AppState.hijriMonthsAr : AppState.hijriMonths;
        return AppPage(
          title: app.t('calendar'),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
            children: [
              AppCard(
                color: p.surface2,
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(app.t('today'), style: TextStyle(fontSize: 12, color: p.muted)),
                  Text('${today.d} ${mon[today.m - 1]} ${today.y} AH', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: p.primary)),
                  Text(fmt(todayG), style: TextStyle(color: p.muted)),
                ]),
              ),
              const SizedBox(height: 12),
              for (final u in list)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: AppCard(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        Expanded(child: Text(u.title, style: const TextStyle(fontWeight: FontWeight.w700))),
                        Text(_inDays(context, u.date.difference(todayG).inDays), style: TextStyle(fontSize: 12, color: p.primary, fontWeight: FontWeight.w600)),
                      ]),
                      const SizedBox(height: 4),
                      Text(fmt(u.date), style: TextStyle(fontSize: 12, color: p.muted)),
                      const SizedBox(height: 6),
                      Text(u.note, style: const TextStyle(fontSize: 13.5, height: 1.45)),
                      if (u.disputed) Padding(padding: const EdgeInsets.only(top: 6), child: Text(app.t('disputed'), style: TextStyle(fontSize: 11.5, color: p.muted, fontStyle: FontStyle.italic))),
                      if (u.source != null) Padding(padding: const EdgeInsets.only(top: 6), child: Text('${app.t('source')}: ${u.source}', style: TextStyle(fontSize: 11.5, color: p.muted))),
                    ]),
                  ),
                ),
              const SizedBox(height: 4),
              Text(app.t('calendar_note'), style: TextStyle(fontSize: 11, color: p.muted)),
            ],
          ),
        );
      },
    );
  }

  String _inDays(BuildContext c, int days) {
    if (days <= 0) return app.t('today');
    return '${app.t('in')} $days ${app.t('days')}';
  }
}
