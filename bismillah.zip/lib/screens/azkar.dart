import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../services.dart';
import '../state.dart';
import '../widgets.dart';

class AzkarScreen extends StatefulWidget {
  const AzkarScreen({super.key});
  @override
  State<AzkarScreen> createState() => _AzkarScreenState();
}

class _AzkarScreenState extends State<AzkarScreen> {
  int cat = 0; // index, -1 = favorites

  String shareText(Map it) => '${it['ar']}\n\n${it['en']}\n\n— ${it['src']}${(it['grade'] as String).isNotEmpty ? '\n${it['grade']}' : ''}';

  @override
  Widget build(BuildContext context) {
    final p = pal(context);
    return FutureBuilder<List<dynamic>>(
      future: Repo.duas(),
      builder: (context, snap) {
        if (!snap.hasData) return const Loading();
        final cats = snap.data!;
        return ListenableBuilder(
          listenable: app,
          builder: (context, _) {
            final List items = cat == -1
                ? [for (final c in cats) for (final it in c['items']) if (app.duaFavs.contains(it['src'] + it['t'])) it]
                : (cats[cat]['items'] as List);
            return Column(children: [
              Padding(padding: const EdgeInsets.fromLTRB(20, 8, 16, 8), child: Row(children: [Text('${app.t('azkar')} & ${app.t('duas')}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700))])),
              SizedBox(
                height: 40,
                child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16), children: [
                  Padding(padding: const EdgeInsets.only(right: 8), child: Pill('♥ ${app.t('favorites')}', on: cat == -1, onTap: () => setState(() => cat = -1))),
                  for (int i = 0; i < cats.length; i++) Padding(padding: const EdgeInsets.only(right: 8), child: Pill(cats[i]['cat'], on: cat == i, onTap: () => setState(() => cat = i))),
                ]),
              ),
              Expanded(
                child: items.isEmpty
                    ? Center(child: Text(app.t('no_results'), style: TextStyle(color: p.muted)))
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 12, 16, 120),
                        itemCount: items.length,
                        itemBuilder: (_, i) {
                          final it = items[i] as Map;
                          final fav = app.duaFavs.contains(it['src'] + it['t']);
                          return Padding(
                            padding: const EdgeInsets.only(bottom: 12),
                            child: AppCard(
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(it['t'], style: TextStyle(fontWeight: FontWeight.w700, color: p.primary, fontSize: 15)),
                                const SizedBox(height: 4),
                                ArabicText(it['ar'], size: 24),
                                const SizedBox(height: 4),
                                Text(it['en'], style: const TextStyle(height: 1.55, fontSize: 14)),
                                if ((it['ur'] as String).isNotEmpty) ...[const SizedBox(height: 6), UrduText(it['ur'], size: 16)],
                                const SizedBox(height: 10),
                                Container(
                                  width: double.infinity,
                                  padding: const EdgeInsets.all(10),
                                  decoration: BoxDecoration(color: p.surface2, borderRadius: BorderRadius.circular(14)),
                                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                    Text('${app.t('source')}: ${it['src']}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                                    if ((it['grade'] as String).isNotEmpty) Text('${app.t('grade')}: ${it['grade']}', style: TextStyle(fontSize: 11.5, color: p.muted)),
                                  ]),
                                ),
                                Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                                  IconButton(
                                    icon: Icon(fav ? Icons.favorite_rounded : Icons.favorite_border_rounded, color: p.primary),
                                    onPressed: () => app.update(() => fav ? app.duaFavs.remove(it['src'] + it['t']) : app.duaFavs.add(it['src'] + it['t'])),
                                  ),
                                  IconButton(icon: Icon(Icons.copy_rounded, color: p.muted, size: 20), onPressed: () => copyText(context, shareText(it))),
                                  IconButton(icon: Icon(Icons.ios_share_rounded, color: p.muted, size: 20), onPressed: () => Share.share(shareText(it))),
                                ]),
                              ]),
                            ),
                          );
                        },
                      ),
              ),
            ]);
          },
        );
      },
    );
  }
}
