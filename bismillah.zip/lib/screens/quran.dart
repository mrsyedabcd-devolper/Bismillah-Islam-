import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:share_plus/share_plus.dart';
import '../services.dart';
import '../state.dart';
import '../widgets.dart';

class QuranScreen extends StatefulWidget {
  const QuranScreen({super.key});
  @override
  State<QuranScreen> createState() => _QuranScreenState();
}

class _QuranScreenState extends State<QuranScreen> with SingleTickerProviderStateMixin {
  late final TabController tc = TabController(length: 3, vsync: this);
  String q = '';

  @override
  Widget build(BuildContext context) {
    final p = pal(context);
    return AppPage(
      title: app.t('quran'),
      actions: [IconButton(icon: const Icon(Icons.manage_search_rounded), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const QuranSearchPage())))],
      body: FutureBuilder<List<Surah>>(
        future: Repo.quran(),
        builder: (context, snap) {
          if (!snap.hasData) return const Loading();
          final list = snap.data!;
          return ListenableBuilder(
            listenable: app,
            builder: (context, _) => Column(children: [
              if (app.lastSurah > 0)
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                  child: AppCard(
                    color: p.surface2,
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SurahReader(surah: list[app.lastSurah - 1], startAyah: app.lastAyah))),
                    child: Row(children: [
                      Icon(Icons.bookmark_rounded, color: p.primary),
                      const SizedBox(width: 10),
                      Expanded(child: Text('${app.t('last_read')}: ${list[app.lastSurah - 1].en} · ${app.lastAyah}', style: const TextStyle(fontWeight: FontWeight.w600))),
                      Icon(Icons.chevron_right_rounded, color: p.muted),
                    ]),
                  ),
                ),
              TabBar(controller: tc, labelColor: p.primary, unselectedLabelColor: p.muted, indicatorColor: p.primary, tabs: [Tab(text: app.t('surahs')), Tab(text: app.t('juz')), Tab(text: app.t('bookmarks'))]),
              Expanded(child: TabBarView(controller: tc, children: [_surahTab(list), _juzTab(list), _markTab(list)])),
            ]),
          );
        },
      ),
    );
  }

  Widget _surahTab(List<Surah> list) {
    final p = pal(context);
    final f = q.isEmpty ? list : list.where((s) => s.en.toLowerCase().contains(q.toLowerCase()) || s.name.toLowerCase().contains(q.toLowerCase()) || s.n.toString() == q || s.ar.contains(q)).toList();
    return Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 10, 16, 6), child: SearchBox(hint: app.t('search'), onChanged: (v) => setState(() => q = v.trim()))),
      Expanded(
        child: ListView.builder(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
          itemCount: f.length,
          itemBuilder: (_, i) {
            final s = f[i];
            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: AppCard(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SurahReader(surah: s))),
                child: Row(children: [
                  Container(
                    width: 42,
                    height: 42,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(color: p.surface2, borderRadius: BorderRadius.circular(14)),
                    child: Text('${s.n}', style: TextStyle(fontWeight: FontWeight.w700, color: p.primary)),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(s.name, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
                      Text('${s.en} · ${s.place} · ${s.a.length} ${app.t('verses')}', style: TextStyle(fontSize: 11.5, color: p.muted)),
                    ]),
                  ),
                  Text(s.ar.replaceAll('سُوْرَةُ ', ''), style: TextStyle(fontFamily: 'Amiri', fontSize: 22, color: p.primary)),
                ]),
              ),
            );
          },
        ),
      ),
    ]);
  }

  Widget _juzTab(List<Surah> list) {
    final p = pal(context);
    final starts = <int, List<int>>{};
    for (final s in list) {
      for (int i = 0; i < s.a.length; i++) {
        final j = s.a[i][3] as int;
        starts.putIfAbsent(j, () => [s.n, i + 1]);
      }
    }
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      itemCount: 30,
      itemBuilder: (_, i) {
        final st = starts[i + 1]!;
        final s = list[st[0] - 1];
        return Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: AppCard(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SurahReader(surah: s, startAyah: st[1]))),
            child: Row(children: [
              Container(width: 42, height: 42, alignment: Alignment.center, decoration: BoxDecoration(color: p.surface2, borderRadius: BorderRadius.circular(14)), child: Text('${i + 1}', style: TextStyle(fontWeight: FontWeight.w700, color: p.primary))),
              const SizedBox(width: 12),
              Expanded(child: Text('${app.t('juz')} ${i + 1}', style: const TextStyle(fontWeight: FontWeight.w600))),
              Text('${s.en} ${st[1]}', style: TextStyle(fontSize: 12, color: p.muted)),
            ]),
          ),
        );
      },
    );
  }

  Widget _markTab(List<Surah> list) {
    final marks = app.quranMarks.toList()..sort((a, b) {
        final x = a.split(':').map(int.parse).toList(), y = b.split(':').map(int.parse).toList();
        return x[0] != y[0] ? x[0].compareTo(y[0]) : x[1].compareTo(y[1]);
      });
    if (marks.isEmpty) return Center(child: Text(app.t('no_results'), style: TextStyle(color: pal(context).muted)));
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      itemCount: marks.length,
      itemBuilder: (_, i) {
        final x = marks[i].split(':').map(int.parse).toList();
        final s = list[x[0] - 1];
        return Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: AppCard(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SurahReader(surah: s, startAyah: x[1]))),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${s.en} ${x[0]}:${x[1]}', style: TextStyle(fontWeight: FontWeight.w700, color: pal(context).primary)),
              const SizedBox(height: 6),
              ArabicText(s.a[x[1] - 1][0] as String, size: 22),
            ]),
          ),
        );
      },
    );
  }
}

class QuranSearchPage extends StatefulWidget {
  const QuranSearchPage({super.key});
  @override
  State<QuranSearchPage> createState() => _QuranSearchPageState();
}

class _QuranSearchPageState extends State<QuranSearchPage> {
  List<List<int>> hits = [];
  String q = '';
  bool searched = false;

  Future<void> run(String text) async {
    final list = await Repo.quran();
    final needle = text.trim().toLowerCase();
    final out = <List<int>>[];
    if (needle.length >= 2) {
      for (final s in list) {
        for (int i = 0; i < s.a.length; i++) {
          final a = s.a[i];
          if ((a[0] as String).contains(needle) || (a[1] as String).toLowerCase().contains(needle) || (a[2] as String).contains(needle)) {
            out.add([s.n, i + 1]);
            if (out.length >= 100) break;
          }
        }
        if (out.length >= 100) break;
      }
    }
    setState(() {
      hits = out;
      searched = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    final p = pal(context);
    return AppPage(
      title: app.t('search'),
      body: FutureBuilder<List<Surah>>(
        future: Repo.quran(),
        builder: (context, snap) {
          if (!snap.hasData) return const Loading();
          final list = snap.data!;
          return Column(children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: TextField(
                autofocus: true,
                textInputAction: TextInputAction.search,
                onSubmitted: run,
                decoration: InputDecoration(hintText: '${app.t('english')} / ${app.t('urdu')} / العربية', prefixIcon: const Icon(Icons.search_rounded)),
              ),
            ),
            Expanded(
              child: hits.isEmpty
                  ? Center(child: Text(searched ? app.t('no_results') : '', style: TextStyle(color: p.muted)))
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                      itemCount: hits.length,
                      itemBuilder: (_, i) {
                        final h = hits[i];
                        final s = list[h[0] - 1];
                        final a = s.a[h[1] - 1];
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: AppCard(
                            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SurahReader(surah: s, startAyah: h[1]))),
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text('${s.en} ${h[0]}:${h[1]}', style: TextStyle(fontWeight: FontWeight.w700, color: p.primary)),
                              const SizedBox(height: 6),
                              Text(a[1] as String, style: const TextStyle(height: 1.5)),
                            ]),
                          ),
                        );
                      },
                    ),
            ),
          ]);
        },
      ),
    );
  }
}

class SurahReader extends StatefulWidget {
  final Surah surah;
  final int startAyah;
  const SurahReader({super.key, required this.surah, this.startAyah = 1});
  @override
  State<SurahReader> createState() => _SurahReaderState();
}

class _SurahReaderState extends State<SurahReader> {
  final AudioPlayer player = AudioPlayer();
  late final List<GlobalKey> keys = List.generate(widget.surah.a.length, (_) => GlobalKey());
  int playing = -1; // 0-based ayah index
  bool loadingAudio = false;
  int selected = -1;

  @override
  void initState() {
    super.initState();
    if (widget.startAyah > 1) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        final c = keys[(widget.startAyah - 1).clamp(0, keys.length - 1) as int].currentContext;
        if (c != null) Scrollable.ensureVisible(c, duration: const Duration(milliseconds: 300), alignment: .05);
      });
    }
    player.processingStateStream.listen((s) {
      if (s == ProcessingState.completed && playing >= 0) _next();
    });
    // no notifyListeners here: we are inside a build phase
    app.lastSurah = widget.surah.n;
    app.lastAyah = widget.startAyah;
    app.p.setInt('lastSurah', app.lastSurah);
    app.p.setInt('lastAyah', app.lastAyah);
  }

  Future<void> _playIndex(int i) async {
    if (i >= widget.surah.a.length) {
      setState(() => playing = -1);
      return;
    }
    setState(() {
      playing = i;
      loadingAudio = true;
    });
    final g = Repo.globalAyah(widget.surah.n, i + 1);
    try {
      await player.setUrl('https://cdn.islamic.network/quran/audio/128/ar.alafasy/$g.mp3');
      setState(() => loadingAudio = false);
      final c = keys[i].currentContext;
      if (c != null) Scrollable.ensureVisible(c, duration: const Duration(milliseconds: 300), alignment: .05);
      await player.play();
    } catch (e) {
      if (mounted) {
        setState(() {
          playing = -1;
          loadingAudio = false;
        });
        toast(context, app.t('online_only'));
      }
    }
  }

  void _next() => _playIndex(playing + 1);

  Future<void> _stop() async {
    await player.stop();
    if (mounted) setState(() => playing = -1);
  }

  @override
  void dispose() {
    player.dispose();
    super.dispose();
  }

  String _shareText(int i) {
    final s = widget.surah;
    final a = s.a[i];
    return '${a[0]}\n\n${a[1]}\n\n— Qur\'an ${s.n}:${i + 1} (${s.en})';
  }

  @override
  Widget build(BuildContext context) {
    final p = pal(context);
    final s = widget.surah;
    return AppPage(
      title: '${s.n}. ${s.name}',
      actions: [
        IconButton(
          tooltip: app.t('play'),
          icon: loadingAudio ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : Icon(playing >= 0 ? Icons.stop_circle_rounded : Icons.play_circle_rounded, color: p.primary, size: 30),
          onPressed: () => playing >= 0 ? _stop() : _playIndex((widget.startAyah - 1).clamp(0, s.a.length - 1) as int),
        ),
      ],
      body: ListenableBuilder(
        listenable: app,
        builder: (context, _) => SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 40),
          child: Column(children: [
            AppCard(
              color: p.surface2,
              child: Column(children: [
                Text(s.ar, style: TextStyle(fontFamily: 'Amiri', fontSize: 32, color: p.primary)),
                Text('${s.en} · ${s.place} · ${s.a.length} ${app.t('verses')}', style: TextStyle(color: p.muted, fontSize: 12)),
                if (s.n != 1 && s.n != 9) ...[const SizedBox(height: 8), const ArabicText('بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ', size: 28, align: TextAlign.center)],
              ]),
            ),
            const SizedBox(height: 10),
            for (int i = 0; i < s.a.length; i++) _ayah(context, i),
          ]),
        ),
      ),
    );
  }

  Widget _ayah(BuildContext context, int i) {
    final p = pal(context);
    final s = widget.surah;
    final a = s.a[i];
    final mark = '${s.n}:${i + 1}';
    final marked = app.quranMarks.contains(mark);
    final isPlaying = playing == i;
    return Padding(
      key: keys[i],
      padding: const EdgeInsets.only(bottom: 10),
      child: AppCard(
        color: isPlaying ? p.surface2 : null,
        padding: const EdgeInsets.fromLTRB(14, 10, 14, 6),
        onTap: () {
          setState(() => selected = selected == i ? -1 : i);
          app.update(() {
            app.lastSurah = s.n;
            app.lastAyah = i + 1;
            app.p.setInt('lastSurah', s.n);
            app.p.setInt('lastAyah', i + 1);
          });
        },
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
              decoration: BoxDecoration(color: p.primary, borderRadius: BorderRadius.circular(10)),
              child: Text('${s.n}:${i + 1}', style: TextStyle(color: p.onPrimary, fontSize: 11, fontWeight: FontWeight.w600)),
            ),
            if ((a[4] as int) == 1) ...[const SizedBox(width: 8), Pill('۩ ${app.t('sajdah')}', on: true)],
            const Spacer(),
            Text('${app.t('juz')} ${a[3]}', style: TextStyle(fontSize: 11, color: p.muted)),
          ]),
          ArabicText(a[0] as String, size: app.fontSize),
          if (app.showEn) ...[const SizedBox(height: 4), Text(a[1] as String, style: const TextStyle(height: 1.55, fontSize: 14.5))],
          if (app.showUr && (a[2] as String).isNotEmpty) ...[const SizedBox(height: 4), UrduText(a[2] as String, size: 16)],
          Row(mainAxisAlignment: MainAxisAlignment.end, children: [
            IconButton(visualDensity: VisualDensity.compact, icon: Icon(isPlaying ? Icons.stop_rounded : Icons.play_arrow_rounded, color: p.primary), onPressed: () => isPlaying ? _stop() : _playIndex(i)),
            IconButton(
              visualDensity: VisualDensity.compact,
              icon: Icon(marked ? Icons.bookmark_rounded : Icons.bookmark_border_rounded, color: p.primary),
              onPressed: () => app.update(() => marked ? app.quranMarks.remove(mark) : app.quranMarks.add(mark)),
            ),
            IconButton(visualDensity: VisualDensity.compact, icon: Icon(Icons.copy_rounded, color: p.muted, size: 20), onPressed: () => copyText(context, _shareText(i))),
            IconButton(visualDensity: VisualDensity.compact, icon: Icon(Icons.ios_share_rounded, color: p.muted, size: 20), onPressed: () => Share.share(_shareText(i))),
          ]),
        ]),
      ),
    );
  }
}
