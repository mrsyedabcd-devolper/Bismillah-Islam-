import 'package:flutter/material.dart';
import '../prayer_calc.dart';
import '../services.dart';
import '../state.dart';
import '../widgets.dart';

Future<void> showCitySearch(BuildContext context) async {
  await showSheet(context, app.t('search_city'), const _CitySearch());
}

class _CitySearch extends StatefulWidget {
  const _CitySearch();
  @override
  State<_CitySearch> createState() => _CitySearchState();
}

class _CitySearchState extends State<_CitySearch> {
  final c = TextEditingController();
  List<Map<String, dynamic>> res = [];
  bool busy = false;
  String? err;

  Future<void> go() async {
    if (c.text.trim().length < 2) return;
    setState(() {
      busy = true;
      err = null;
    });
    try {
      res = await AppState.searchCity(c.text.trim());
    } catch (_) {
      err = app.t('online_only');
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> pick(Map<String, dynamic> r) async {
    // default UTC offset = longitude based guess rounded to 0.5h; user can change it.
    final guess = ((r['lng'] as double) / 15 * 2).round() / 2;
    double off = guess;
    final dev = DateTime.now().timeZoneOffset.inMinutes / 60.0;
    // if the city is near the device longitude band, prefer the device offset
    if ((guess - dev).abs() <= 1) off = dev;
    final chosen = await showDialog<double>(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (ctx, set) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          title: Text(app.t('utc_offset')),
          content: DropdownButton<double>(
            value: off,
            isExpanded: true,
            items: [for (double v = -12; v <= 14; v += 0.5) DropdownMenuItem(value: v, child: Text('UTC${v >= 0 ? '+' : ''}${v.toStringAsFixed(v % 1 == 0 ? 0 : 1)}'))],
            onChanged: (v) => set(() => off = v ?? off),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: Text(app.t('cancel'))),
            FilledButton(onPressed: () => Navigator.pop(ctx, off), child: Text(app.t('save'))),
          ],
        ),
      ),
    );
    if (chosen == null) return;
    final parts = (r['name'] as String).split(',');
    final short = parts.length > 2 ? '${parts.first.trim()}, ${parts.last.trim()}' : (r['name'] as String);
    app.setManualLocation(short, r['lat'], r['lng'], (chosen * 60).round());
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(
          controller: c,
          autofocus: true,
          textInputAction: TextInputAction.search,
          onSubmitted: (_) => go(),
          decoration: InputDecoration(hintText: app.t('search_city'), suffixIcon: IconButton(onPressed: go, icon: const Icon(Icons.search_rounded))),
        ),
        const SizedBox(height: 10),
        if (busy) const Padding(padding: EdgeInsets.all(20), child: CircularProgressIndicator()),
        if (err != null) Padding(padding: const EdgeInsets.all(12), child: Text(err!)),
        Flexible(
          child: ListView(shrinkWrap: true, children: [
            for (final r in res) ListTile(leading: const Icon(Icons.place_rounded), title: Text(r['name'], maxLines: 2, overflow: TextOverflow.ellipsis), onTap: () => pick(r)),
          ]),
        ),
      ]);
}

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Widget section(BuildContext c, String title, List<Widget> kids) {
    final p = pal(c);
    return Padding(
      padding: const EdgeInsets.only(top: 18),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(padding: const EdgeInsets.only(left: 6, bottom: 8), child: Text(title, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: p.primary, letterSpacing: .4))),
        AppCard(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8), child: Column(children: kids)),
      ]),
    );
  }

  Widget row(String label, Widget trailing, {String? sub}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500)), if (sub != null) Text(sub, style: const TextStyle(fontSize: 11.5, color: Colors.grey))])),
          trailing,
        ]),
      );

  Widget seg<T>(BuildContext c, T value, Map<T, String> opts, ValueChanged<T> on) {
    final p = pal(c);
    return Wrap(spacing: 6, runSpacing: 6, children: [for (final e in opts.entries) Pill(e.value, on: e.key == value, onTap: () => on(e.key))]);
  }

  @override
  Widget build(BuildContext context) {
    final p = pal(context);
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) => ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
        children: [
          Text(app.t('settings'), style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w700)),
          section(context, app.t('language').toUpperCase(), [
            Padding(padding: const EdgeInsets.symmetric(vertical: 10), child: seg(context, app.lang, {'en': 'English', 'ur': 'اردو', 'ar': 'العربية'}, (v) => app.update(() => app.lang = v, reschedule: true))),
          ]),
          section(context, app.t('theme').toUpperCase(), [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: seg(context, app.themeMode, {ThemeMode.system: app.t('system'), ThemeMode.light: app.t('light'), ThemeMode.dark: app.t('dark')}, (v) => app.update(() => app.themeMode = v)),
            ),
          ]),
          section(context, app.t('location').toUpperCase(), [
            row(app.loc?.name ?? app.t('detecting'), const SizedBox.shrink(), sub: app.loc == null ? null : '${app.loc!.lat.toStringAsFixed(4)}, ${app.loc!.lng.toStringAsFixed(4)} · ${app.loc!.auto ? 'GPS' : 'UTC${(app.loc!.offsetMin! / 60).toStringAsFixed(1)}'}'),
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Wrap(spacing: 8, runSpacing: 8, children: [
                FilledButton.icon(onPressed: () => app.useGps(), icon: const Icon(Icons.my_location_rounded, size: 18), label: Text(app.t('use_gps'))),
                OutlinedButton.icon(onPressed: () => showCitySearch(context), icon: const Icon(Icons.search_rounded, size: 18), label: Text(app.t('search_city'))),
              ]),
            ),
          ]),
          section(context, app.t('method').toUpperCase(), [
            for (final m in kMethods)
              RadioListTile<String>(
                dense: true,
                contentPadding: EdgeInsets.zero,
                activeColor: p.primary,
                value: m.id,
                groupValue: app.method,
                title: Text(m.name, style: const TextStyle(fontSize: 13.5)),
                onChanged: (v) => app.update(() => app.method = v!, reschedule: true),
              ),
            const Divider(),
            row(app.t('asr_method'), const SizedBox.shrink()),
            Padding(padding: const EdgeInsets.only(bottom: 10), child: seg(context, app.asr, {1: app.t('standard'), 2: app.t('hanafi')}, (v) => app.update(() => app.asr = v, reschedule: true))),
          ]),
          section(context, app.t('adjust').toUpperCase(), [
            for (final k in ['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'])
              row(
                app.t(k),
                Row(children: [
                  IconButton(visualDensity: VisualDensity.compact, onPressed: () => app.update(() => app.adjust[k] = (app.adjust[k] ?? 0) - 1, reschedule: true), icon: const Icon(Icons.remove_circle_outline_rounded)),
                  SizedBox(width: 36, child: Text('${(app.adjust[k] ?? 0) > 0 ? '+' : ''}${app.adjust[k] ?? 0}', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600))),
                  IconButton(visualDensity: VisualDensity.compact, onPressed: () => app.update(() => app.adjust[k] = (app.adjust[k] ?? 0) + 1, reschedule: true), icon: const Icon(Icons.add_circle_outline_rounded)),
                ]),
              ),
            row(app.t('hijri_adj'), Row(children: [
              IconButton(visualDensity: VisualDensity.compact, onPressed: () => app.update(() => app.hijriAdj = (app.hijriAdj - 1).clamp(-3, 3) as int), icon: const Icon(Icons.remove_circle_outline_rounded)),
              SizedBox(width: 36, child: Text('${app.hijriAdj}', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600))),
              IconButton(visualDensity: VisualDensity.compact, onPressed: () => app.update(() => app.hijriAdj = (app.hijriAdj + 1).clamp(-3, 3) as int), icon: const Icon(Icons.add_circle_outline_rounded)),
            ])),
          ]),
          section(context, app.t('auto_azan').toUpperCase(), [
            for (final k in kPrayerKeys) _PrayerAzanTile(k: k),
            const Divider(),
            row(app.t('reminder_before'), DropdownButton<int>(
              value: app.preMin,
              underline: const SizedBox.shrink(),
              items: [for (final v in [0, 5, 10, 15, 20, 30]) DropdownMenuItem(value: v, child: Text(v == 0 ? app.t('off') : '$v ${app.t('minutes')}'))],
              onChanged: (v) => app.update(() => app.preMin = v ?? 0, reschedule: true),
            )),
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: FilledButton.tonalIcon(
                onPressed: () async {
                  final ok = await NotifService.instance.requestPermissions();
                  await app.rescheduleAzan();
                  if (context.mounted) toast(context, ok ? 'OK' : app.t('loc_denied'));
                },
                icon: const Icon(Icons.notifications_active_rounded),
                label: Text(app.t('allow')),
              ),
            ),
          ]),
          section(context, app.t('quran').toUpperCase(), [
            row(app.t('font_size'), Text('${app.fontSize.round()}')),
            Slider(min: 16, max: 34, divisions: 18, value: app.fontSize, onChanged: (v) => app.update(() => app.fontSize = v)),
            row(app.t('english'), Switch(value: app.showEn, onChanged: (v) => app.update(() => app.showEn = v))),
            row(app.t('urdu'), Switch(value: app.showUr, onChanged: (v) => app.update(() => app.showUr = v))),
          ]),
          section(context, app.t('data_sources').toUpperCase(), [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Text(
                "Quran: Uthmani Hafs text; Saheeh International and Fateh Muhammad Jalandhry translations.\n"
                "Hadith: Bukhari, Muslim, Ibn Majah, Muwatta Malik, Nawawi 40, Qudsi 40 with gradings as given by the named scholars.\n"
                "Datasets: fawazahmed0/quran-api and fawazahmed0/hadith-api (open source).\n"
                "Prayer times are calculated on your device from your GPS location.",
                style: TextStyle(fontSize: 12.5, height: 1.5, color: p.muted),
              ),
            ),
          ]),
        ],
      ),
    );
  }
}

class _PrayerAzanTile extends StatelessWidget {
  final String k;
  const _PrayerAzanTile({required this.k});
  @override
  Widget build(BuildContext context) {
    final p = pal(context);
    final pref = app.prefs[k]!;
    return ExpansionTile(
      tilePadding: EdgeInsets.zero,
      shape: const Border(),
      collapsedShape: const Border(),
      title: Text(app.t(k), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
      subtitle: Text(pref.enabled ? '${kSoundNames[pref.sound]} · ${app.t('mode_${pref.mode}')}' : app.t('off'), style: TextStyle(fontSize: 11.5, color: p.muted)),
      trailing: Switch(value: pref.enabled, onChanged: (v) => app.update(() => pref.enabled = v, reschedule: true)),
      children: [
        Align(
          alignment: AlignmentDirectional.centerStart,
          child: Wrap(spacing: 6, runSpacing: 6, children: [
            for (final s in kSounds) Pill(kSoundNames[s]!, on: pref.sound == s, onTap: () => app.update(() => pref.sound = s, reschedule: true)),
          ]),
        ),
        const SizedBox(height: 8),
        Align(
          alignment: AlignmentDirectional.centerStart,
          child: Wrap(spacing: 6, runSpacing: 6, children: [
            for (final m in ['azan', 'notify', 'silent']) Pill(app.t('mode_$m'), on: pref.mode == m, onTap: () => app.update(() => pref.mode = m, reschedule: true)),
          ]),
        ),
        const SizedBox(height: 8),
        Align(
          alignment: AlignmentDirectional.centerStart,
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            OutlinedButton.icon(onPressed: () => AzanPlayer.instance.play(pref.sound), icon: const Icon(Icons.play_arrow_rounded), label: Text(app.t('preview'))),
            const SizedBox(width: 8),
            TextButton(onPressed: AzanPlayer.instance.stop, child: Text(app.t('stop'))),
          ]),
        ),
        const SizedBox(height: 10),
      ],
    );
  }
}
