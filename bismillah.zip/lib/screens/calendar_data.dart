/// Islamic calendar dates. Each entry: hijri month, day, title, note, source (null = calendar date only).
/// Entries marked [disputed] are celebrated by some and not by others; the app says so.
class IslamicEvent {
  final int m, d;
  final String title, note;
  final String? source;
  final bool disputed;
  const IslamicEvent(this.m, this.d, this.title, this.note, {this.source, this.disputed = false});
}

const List<IslamicEvent> kEvents = [
  IslamicEvent(1, 1, 'Islamic New Year', 'Beginning of the Hijri year (1 Muharram).'),
  IslamicEvent(1, 10, 'Ashura (10 Muharram)', 'Fasting on this day is recommended.', source: 'Sahih al-Bukhari 1892 (Ibn Umar)'),
  IslamicEvent(7, 27, "Isra and Mi'raj", 'Scholars differ on the exact date. Not an obligation.', disputed: true),
  IslamicEvent(8, 15, "Shab-e-Barat (15 Sha'ban)", 'Scholars differ on its basis. Not an obligation.', disputed: true),
  IslamicEvent(9, 1, 'Ramadan begins', 'Fasting from dawn to sunset. Moon sighting decides the start.'),
  IslamicEvent(9, 27, 'Night of Qadr (likely)', 'Seek it in the last ten nights, especially the odd nights.', source: 'Jami at-Tirmidhi 3513 (Aishah, dua for Laylat al-Qadr)'),
  IslamicEvent(10, 1, 'Eid al-Fitr', 'Fasting is not allowed on Eid day.'),
  IslamicEvent(12, 9, 'Day of Arafah', 'The main day of Hajj.'),
  IslamicEvent(12, 10, 'Eid al-Adha', 'Qurbani is done on 10 to 13 Dhul Hijjah.'),
  IslamicEvent(12, 11, 'Days of Tashreeq', '11 to 13 Dhul Hijjah.'),
  IslamicEvent(3, 12, 'Mawlid an-Nabi (12 Rabi al-Awwal)', 'Scholars differ on celebrating it. Not an obligation.', disputed: true),
];

/// Recurring voluntary fasts with sources.
const List<Map<String, String>> kRecurring = [
  {'key': 'white', 'source': "Sunan an-Nasa'i 2420 (Jarir ibn Abdullah)"},
  {'key': 'monthu', 'source': 'Jami at-Tirmidhi 747 (Abu Hurairah)'},
];
