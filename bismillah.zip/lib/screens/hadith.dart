import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../services.dart';
import '../state.dart';
import '../widgets.dart';

class HadithScreen extends StatelessWidget {
  const HadithScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final p = pal(context);
    return AppPage(
      title: app.t('hadith'),
      actions: [IconButton(icon: const Icon(Icons.bookmarks_rounded), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const HadithMarksPage())))],
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          for (final b in kHadithBooks)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: AppCard(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => HadithBookPage(key_: b[0]))),
                child: Row(children: [
                  Icon(Icons.menu_book_rounded, color: p.primary),
                  const SizedBox(width: 12),
                  Expanded(child: Text(b[1], style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15))),
                  Text(b[2], style: TextStyle(fontFamily: 'Amiri', fontSize: 20, color: p.primary)),
                ]),
              ),
            ),
        ],
      ),
    );
  }
}

class HadithBookPage extends StatefulWidget {
  final String key_;
  const HadithBookPage({super.key, required this.key_});
  @override
  State<HadithBookPage> createState() => _HadithBookPageState();
}

class _HadithBookPageState extends State<HadithBookPage> {
  List<List<dynamic>>? hits;

  void search(HCollection c, String text) {
    final q = text.trim().toLowerCase();
    if (q.isEmpty) {
      setState(() => hits = null);
      return;
    }
    final n = int.tryParse(q);
    final out = <List<dynamic>>[];
    for (final h in c.h) {
      if (n != null ? h[0] == n : (h[3] as String).toLowerCase().contains(q)) {
        out.add(h);
        if (out.length >= 80) break;
      }
    }
    setState(() => hits = out);
  }

  @override
  Widget build(BuildContext context) {
    final p = pal(context);
    return FutureBuilder<HCollection>(
      future: Repo.hadith(widget.key_),
      builder: (context, snap) {
        final title = kHadithBooks.firstWhere((b) => b[0] == widget.key_)[1];
        if (!snap.hasData) return AppPage(title: title, body: const Loading());
        final c = snap.data!;
        final secs = c.sections.entries.where((e) => e.key != '0').toList()..sort((a, b) => int.parse(a.key).compareTo(int.parse(b.key)));
        return AppPage(
          title: title,
          body: Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
              child: TextField(
                textInputAction: TextInputAction.search,
                onSubmitted: (v) => search(c, v),
                onChanged: (v) {
                  if (v.isEmpty) search(c, v);
                },
                decoration: InputDecoration(hintText: '${app.t('go_number')} · ${c.h.length}', prefixIcon: const Icon(Icons.search_rounded)),
              ),
            ),
            Expanded(
              child: hits != null
                  ? (hits!.isEmpty
                      ? Center(child: Text(app.t('no_results'), style: TextStyle(color: p.muted)))
                      : ListView.builder(padding: const EdgeInsets.fromLTRB(16, 0, 16, 24), itemCount: hits!.length, itemBuilder: (_, i) => HadithTile(col: c, h: hits![i])))
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                      itemCount: secs.length,
                      itemBuilder: (_, i) {
                        final e = secs[i];
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: AppCard(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => HadithSectionPage(col: c, sectionId: e.key))),
                            child: Row(children: [
                              Container(width: 38, height: 38, alignment: Alignment.center, decoration: BoxDecoration(color: p.surface2, borderRadius: BorderRadius.circular(12)), child: Text(e.key, style: TextStyle(fontWeight: FontWeight.w700, color: p.primary, fontSize: 12))),
                              const SizedBox(width: 12),
                              Expanded(child: Text(e.value, style: const TextStyle(fontWeight: FontWeight.w500))),
                            ]),
                          ),
                        );
                      },
                    ),
            ),
          ]),
        );
      },
    );
  }
}

class HadithSectionPage extends StatelessWidget {
  final HCollection col;
  final String sectionId;
  const HadithSectionPage({super.key, required this.col, required this.sectionId});
  @override
  Widget build(BuildContext context) {
    final items = col.h.where((h) => h[1].toString() == sectionId).toList();
    return AppPage(
      title: col.sections[sectionId] ?? col.name,
      body: ListView.builder(padding: const EdgeInsets.fromLTRB(16, 4, 16, 24), itemCount: items.length, itemBuilder: (_, i) => HadithTile(col: col, h: items[i])),
    );
  }
}

class HadithTile extends StatelessWidget {
  final HCollection col;
  final List<dynamic> h;
  const HadithTile({super.key, required this.col, required this.h});
  @override
  Widget build(BuildContext context) {
    final p = pal(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: AppCard(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => HadithDetailPage(col: col, hadith: h))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${col.name} · ${h[0]}', style: TextStyle(fontWeight: FontWeight.w700, color: p.primary, fontSize: 12.5)),
          const SizedBox(height: 6),
          Text(h[3] as String, maxLines: 4, overflow: TextOverflow.ellipsis, style: const TextStyle(height: 1.5, fontSize: 13.5)),
          if ((h[5] as String).isNotEmpty || col.key == 'bukhari' || col.key == 'muslim') ...[const SizedBox(height: 6), Text((h[5] as String).isEmpty ? 'Sahih' : (h[5] as String).split(';').first, style: TextStyle(fontSize: 11.5, color: p.muted))],
        ]),
      ),
    );
  }
}

class HadithDetailPage extends StatelessWidget {
  final HCollection col;
  final List<dynamic> hadith;
  const HadithDetailPage({super.key, required this.col, required this.hadith});

  String get gradeText {
    final g = hadith[5] as String;
    if (g.isNotEmpty) return g;
    if (col.key == 'bukhari' || col.key == 'muslim') return 'Sahih (agreed upon by scholars)';
    return '';
  }

  String shareText() => '${hadith[2]}\n\n${hadith[3]}\n\n— ${col.name}, Hadith ${hadith[0]}${gradeText.isNotEmpty ? '\n$gradeText' : ''}';

  @override
  Widget build(BuildContext context) {
    final p = pal(context);
    final mark = '${col.key}:${hadith[0]}';
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final marked = app.hadithMarks.contains(mark);
        return AppPage(
          title: '${col.name} · ${hadith[0]}',
          actions: [
            IconButton(icon: Icon(marked ? Icons.bookmark_rounded : Icons.bookmark_border_rounded, color: p.primary), onPressed: () => app.update(() => marked ? app.hadithMarks.remove(mark) : app.hadithMarks.add(mark))),
            IconButton(icon: const Icon(Icons.copy_rounded), onPressed: () => copyText(context, shareText())),
            IconButton(icon: const Icon(Icons.ios_share_rounded), onPressed: () => Share.share(shareText())),
          ],
          body: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 32), children: [
            AppCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                ArabicText(hadith[2] as String, size: 24),
                const Divider(height: 28),
                Text(hadith[3] as String, style: const TextStyle(height: 1.6, fontSize: 15)),
                if ((hadith[4] as String).isNotEmpty) ...[const Divider(height: 28), UrduText(hadith[4] as String, size: 17)],
              ]),
            ),
            const SizedBox(height: 12),
            AppCard(
              color: p.surface2,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(app.t('source'), style: TextStyle(fontWeight: FontWeight.w700, color: p.primary, fontSize: 12)),
                Text('${col.name}, Hadith ${hadith[0]}${col.sections[hadith[1].toString()] != null && col.sections[hadith[1].toString()]!.isNotEmpty ? '\n${col.sections[hadith[1].toString()]}' : ''}'),
                if (gradeText.isNotEmpty) ...[
                  const SizedBox(height: 10),
                  Text(app.t('grade'), style: TextStyle(fontWeight: FontWeight.w700, color: p.primary, fontSize: 12)),
                  for (final g in gradeText.split('; ')) Text(g, style: const TextStyle(fontSize: 13)),
                ],
              ]),
            ),
          ]),
        );
      },
    );
  }
}

class HadithMarksPage extends StatelessWidget {
  const HadithMarksPage({super.key});
  @override
  Widget build(BuildContext context) {
    final p = pal(context);
    return AppPage(
      title: app.t('bookmarks'),
      body: ListenableBuilder(
        listenable: app,
        builder: (context, _) {
          final marks = app.hadithMarks.toList();
          if (marks.isEmpty) return Center(child: Text(app.t('no_results'), style: TextStyle(color: p.muted)));
          return ListView.builder(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
            itemCount: marks.length,
            itemBuilder: (_, i) {
              final parts = marks[i].split(':');
              return FutureBuilder<HCollection>(
                future: Repo.hadith(parts[0]),
                builder: (_, s) {
                  if (!s.hasData) return const SizedBox(height: 60);
                  final n = int.parse(parts[1]);
                  final h = s.data!.h.firstWhere((x) => x[0] == n);
                  return HadithTile(col: s.data!, h: h);
                },
              );
            },
          );
        },
      ),
    );
  }
}
