import 'dart:ui' show FontFeature;
import 'package:flutter/material.dart';
import '../hijri.dart';
import '../prayer_calc.dart';
import '../services.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'calendar.dart';
import 'hadith.dart';
import 'tracker.dart';
import 'quran.dart';
import 'settings.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  String hijriText() {
    final d = app.nowLoc.add(Duration(days: app.hijriAdj));
    final h = hFromJdn(gToJdn(DateTime(d.year, d.month, d.day)));
    final month = app.lang == 'ar' ? AppState.hijriMonthsAr[h.hMonth - 1] : AppState.hijriMonths[h.hMonth - 1];
    return '${h.hDay} $month ${h.hYear} AH';
  }

  String gregText() {
    final d = app.nowLoc;
    const wd = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    const mo = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return '${wd[d.weekday - 1]}, ${d.day} ${mo[d.month - 1]} ${d.year}';
  }

  @override
  Widget build(BuildContext context) {
    final p = pal(context);
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final t = app.today;
        final next = app.nextPrayer;
        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
          children: [
            Row(children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(gradient: LinearGradient(colors: p.hero), borderRadius: BorderRadius.circular(16)),
                child: Padding(padding: const EdgeInsets.all(8), child: Image.asset('assets/img/mosque.png', fit: BoxFit.contain)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Bismillah Islam', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                  Text(gregText(), style: TextStyle(fontSize: 12, color: p.muted)),
                ]),
              ),
              IconButton(onPressed: () => app.refreshLocation(), icon: Icon(Icons.my_location_rounded, color: p.primary)),
            ]),
            const SizedBox(height: 16),
            if (t == null) _NoLocation() else _Hero(times: t, next: next, hijri: hijriText()),
            if (t != null) ...[
              const SizedBox(height: 14),
              _PrayerRow(times: t, next: next),
              const SizedBox(height: 6),
              Center(child: Text(app.t('prayer_tracker'), style: TextStyle(fontSize: 11, color: p.muted))),
              const SizedBox(height: 10),
              _ExtraTimes(times: t),
            ],
            const SizedBox(height: 14),
            _Quick(),
            const SizedBox(height: 14),
            const _DailyHadith(),
          ],
        );
      },
    );
  }
}

class _NoLocation extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final p = pal(context);
    final busy = app.locStatus == 'busy' || app.locStatus == 'idle';
    return AppCard(
      child: Column(children: [
        if (busy) ...[CircularProgressIndicator(color: p.primary), const SizedBox(height: 12), Text(app.t('detecting'))] else ...[
          Icon(Icons.location_off_rounded, size: 36, color: p.primary),
          const SizedBox(height: 8),
          Text(app.t('loc_denied'), textAlign: TextAlign.center),
          const SizedBox(height: 12),
          Wrap(spacing: 10, runSpacing: 8, alignment: WrapAlignment.center, children: [
            FilledButton(onPressed: () => app.refreshLocation(), child: Text(app.t('retry'))),
            OutlinedButton(onPressed: () => showCitySearch(context), child: Text(app.t('search_city'))),
          ]),
        ],
      ]),
    );
  }
}

class _Hero extends StatelessWidget {
  final DayTimes times;
  final MapEntry<String, DateTime>? next;
  final String hijri;
  const _Hero({required this.times, required this.next, required this.hijri});

  String cd(Duration d) {
    if (d.isNegative) d = Duration.zero;
    final h = d.inHours, m = d.inMinutes % 60, s = d.inSeconds % 60;
    return '${h.toString().padLeft(2, '0')}:${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final p = pal(context);
    final allOn = kPrayerKeys.every((k) => app.prefs[k]!.enabled);
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(gradient: LinearGradient(colors: p.hero, begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(28)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(Icons.location_on_rounded, size: 15, color: Colors.white.withOpacity(.85)),
          const SizedBox(width: 4),
          Expanded(child: Text(app.loc?.name ?? '', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white.withOpacity(.9), fontSize: 12))),
          Text(hijri, style: TextStyle(color: Colors.white.withOpacity(.9), fontSize: 12)),
        ]),
        const SizedBox(height: 14),
        Text(app.t('next_prayer'), style: TextStyle(color: Colors.white.withOpacity(.85), fontSize: 12)),
        Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Expanded(
            child: Text(next == null ? '-' : app.t(next!.key), style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w700, height: 1.1)),
          ),
          Text(next == null ? '' : app.fmtTime12(next!.value), style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w600)),
        ]),
        const SizedBox(height: 6),
        ValueListenableBuilder<int>(
          valueListenable: app.clock,
          builder: (_, __, ___) => Text(
            next == null ? '' : '${app.t('in')} ${cd(next!.value.difference(DateTime.now().toUtc()))}',
            style: TextStyle(color: Colors.white.withOpacity(.95), fontSize: 15, fontWeight: FontWeight.w500, fontFeatures: const [FontFeature.tabularFigures()]),
          ),
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.fromLTRB(14, 4, 6, 4),
          decoration: BoxDecoration(color: Colors.white.withOpacity(.14), borderRadius: BorderRadius.circular(16)),
          child: Row(children: [
            Expanded(child: Text('${app.t('auto_azan')} · ${app.t('azan_on_time')}', style: const TextStyle(color: Colors.white, fontSize: 12))),
            Switch(
              value: allOn,
              onChanged: (v) => app.update(() {
                for (final k in kPrayerKeys) {
                  app.prefs[k]!.enabled = v;
                }
              }, reschedule: true),
            ),
          ]),
        ),
      ]),
    );
  }
}

class _PrayerRow extends StatelessWidget {
  final DayTimes times;
  final MapEntry<String, DateTime>? next;
  const _PrayerRow({required this.times, required this.next});
  @override
  Widget build(BuildContext context) {
    final p = pal(context);
    final list = app.listFor(times);
    final done = app.prayedToday();
    final nowUtc = DateTime.now().toUtc();
    return Row(children: [
      for (int i = 0; i < list.length; i++)
        Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 3),
            child: GestureDetector(
              onTap: () => app.togglePrayed(i),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: next?.key == list[i].key && next?.value == list[i].value ? p.primary : p.surface,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: next?.key == list[i].key && next?.value == list[i].value ? p.primary : p.border),
                ),
                child: Column(children: [
                  Text(app.t(list[i].key), style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600, color: next?.key == list[i].key && next?.value == list[i].value ? p.onPrimary : p.muted)),
                  const SizedBox(height: 3),
                  Text(app.fmtTime(list[i].value), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: next?.key == list[i].key && next?.value == list[i].value ? p.onPrimary : p.text)),
                  const SizedBox(height: 6),
                  Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: done.contains(i) ? OC.green : (list[i].value.isBefore(nowUtc) ? p.muted.withOpacity(.4) : p.border),
                    ),
                  ),
                ]),
              ),
            ),
          ),
        ),
    ]);
  }
}

class _ExtraTimes extends StatelessWidget {
  final DayTimes times;
  const _ExtraTimes({required this.times});
  @override
  Widget build(BuildContext context) {
    final p = pal(context);
    Widget cell(String k, DateTime d) => Expanded(
          child: Column(children: [
            Text(app.t(k), style: TextStyle(fontSize: 11, color: p.muted)),
            const SizedBox(height: 2),
            Text(app.fmtTime(d), style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
          ]),
        );
    return AppCard(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
      child: Row(children: [cell('sunrise', times.sunrise), cell('duha', times.duha), cell('midnight', times.midnight)]),
    );
  }
}

class _Quick extends StatelessWidget {
  Widget tile(BuildContext c, String img, String label, VoidCallback onTap) {
    final p = pal(c);
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4),
        child: AppCard(
          onTap: onTap,
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
          child: Column(children: [
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(color: p.dark ? const Color(0xFFFFF6EC) : p.surface2, borderRadius: BorderRadius.circular(18)),
              child: Padding(padding: const EdgeInsets.all(5), child: Image.asset('assets/img/$img.png', fit: BoxFit.contain)),
            ),
            const SizedBox(height: 6),
            Text(label, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600)),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        Row(children: [
          tile(context, 'quran', app.t('quran'), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const QuranScreen()))),
          tile(context, 'dua', app.t('hadith'), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const HadithScreen()))),
          tile(context, 'tasbeeh', app.t('tasbeeh'), () => app.tabNotifier.value = 2),
        ]),
        const SizedBox(height: 8),
        Row(children: [
          tile(context, 'qibla', app.t('qibla'), () => app.tabNotifier.value = 3),
          tile(context, 'mosque', app.t('azkar'), () => app.tabNotifier.value = 1),
          tile(context, 'settings', app.t('settings'), () => app.tabNotifier.value = 4),
        ]),
        const SizedBox(height: 8),
        Row(children: [
          tile(context, 'mosque', app.t('prayer_tracker_title'), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TrackerScreen()))),
          tile(context, 'quran', app.t('calendar'), () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CalendarScreen()))),
          const Expanded(child: SizedBox()),
        ]),
      ]);
}

class _DailyHadith extends StatelessWidget {
  const _DailyHadith();
  @override
  Widget build(BuildContext context) {
    final p = pal(context);
    return FutureBuilder<HCollection>(
      future: Repo.hadith('nawawi'),
      builder: (context, snap) {
        if (!snap.hasData) return const SizedBox.shrink();
        final c = snap.data!;
        final n = app.nowLoc;
        final doy = n.difference(DateTime.utc(n.year, 1, 1)).inDays;
        final h = c.h[doy % c.h.length];
        return AppCard(
          color: p.surface2,
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => HadithDetailPage(col: c, hadith: h))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Icon(Icons.auto_stories_rounded, color: p.primary, size: 18),
              const SizedBox(width: 8),
              Text(app.t('daily_hadith'), style: TextStyle(fontWeight: FontWeight.w700, color: p.primary)),
            ]),
            const SizedBox(height: 10),
            Text(h[3] as String, maxLines: 6, overflow: TextOverflow.ellipsis, style: const TextStyle(height: 1.5, fontSize: 13.5)),
            const SizedBox(height: 8),
            Text('${c.name}, ${h[0]}', style: TextStyle(fontSize: 12, color: p.muted)),
          ]),
        );
      },
    );
  }
}
