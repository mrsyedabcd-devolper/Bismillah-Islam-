# Bismillah Islam (Flutter: Android, iOS, Web)

One codebase. No login. Works offline (except Qur'an recitation audio, city search and place names).

## Run it (one time, on your computer)
1. Install Flutter 3.24 or newer: https://docs.flutter.dev/get-started/install
2. Open this folder in a terminal and run:  `./setup.sh`
   (creates the platform folders, applies permissions and notification setup, runs the prayer-time tests)
3. Phone:  `flutter run`        Web:  `flutter run -d chrome`

## Release
- Google Play: `flutter build appbundle`
- App Store: needs a Mac with Xcode. `flutter build ipa`, then upload with Transporter/Xcode.
- Web: `flutter build web --release`, host the `build/web` folder anywhere (HTTPS needed for GPS).

## Before you publish (important)
- iOS (only for iPhone builds): the iOS notification sounds are not in the zip to keep it small. Make them from the azan files, then add them in Xcode:
  `for n in classic alaqsa makkah fajr; do ffmpeg -i assets/azan/azan_$n.mp3 -t 29 -af afade=t=out:st=26:d=3 -ar 22050 -ac 1 native/ios/azan_$n.aiff; done`
  Then add the four `.aiff` files to the Runner target in Xcode.
- Quran translations: Saheeh International and Fateh Muhammad Jalandhry are copyrighted. Get permission or replace them before store release.
- Quran recitation streams from cdn.islamic.network; check its terms for commercial use.
- Azan on iPhone: the alarm sound is limited to about 30 seconds, so the full azan plays only while the app is open. Android plays the full azan.
- Prayer times are computed on the device (PrayTimes.org method). Check a few days against your local mosque timetable before relying on it.

## Content sources
- Qur'an: fawazahmed0/quran-api (Uthmani Hafs text).
- Hadith: fawazahmed0/hadith-api (Bukhari, Muslim, Muwatta Malik, Nawawi 40, Qudsi 40). Gradings come from the dataset; Bukhari and Muslim entries are labelled as agreed-upon Sahih.
- Duas: each one is taken from a specific hadith or Qur'an verse listed in the app. Azkar from Hisn al-Muslim-style collections are NOT yet included; add them from a verified source before claiming completeness.

## Phase 2 (partial)
Added: prayer tracker (today's 5 prayers, jama'ah marks, missed-prayer (qaza) counter with make-up plan, 7-day chart, streak) and Islamic calendar (Hijri date, upcoming Islamic dates with sources, white days and Monday/Thursday fasts). Hijri dates use a tabular calendar that can differ by one day from moon sighting.

Not yet built: sunnah/nafl tracking, monthly stats, learning content (section G 198-215), event reminders, sacred months, Friday checklist, add-to-phone-calendar, moon phase, and the remaining sections H to O.
