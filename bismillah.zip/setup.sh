#!/usr/bin/env bash
# One-time setup. Run inside the orbit_islam folder with Flutter 3.24+ installed.
set -e
flutter create --org com.orbitislam --project-name orbit_islam --platforms=android,ios,web .

python3 tool/patch_platforms.py
flutter pub get
flutter test
echo
echo "Done. Run:  flutter run            (phone)"
echo "            flutter run -d chrome   (web)"
echo "Release:    flutter build appbundle   |  flutter build ipa  |  flutter build web --release"
