import 'package:flutter_test/flutter_test.dart';
import 'package:orbit_islam/prayer_calc.dart';

/// Reference values come from an independent run of the same PrayTimes.org algorithm.
void main() {
  String hm(DateTime utc, int off) {
    final d = utc.add(Duration(minutes: off));
    return '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
  }

  int mins(String s) => int.parse(s.substring(0, 2)) * 60 + int.parse(s.substring(3));

  void near(String got, String want) => expect((mins(got) - mins(want)).abs() <= 1, true, reason: 'got $got want $want');

  test('Karachi 6 Nov 2026 (Karachi method, standard Asr)', () {
    final t = PrayerCalc.compute(date: DateTime(2026, 11, 6), lat: 24.8607, lng: 67.0011, offsetMin: 300, method: methodById('karachi'));
    near(hm(t.fajr, 300), '05:24');
    near(hm(t.sunrise, 300), '06:42');
    near(hm(t.dhuhr, 300), '12:16');
    near(hm(t.asr, 300), '15:26');
    near(hm(t.maghrib, 300), '17:49');
    near(hm(t.isha, 300), '19:07');
  });

  test('Karachi Hanafi Asr', () {
    final t = PrayerCalc.compute(date: DateTime(2026, 11, 6), lat: 24.8607, lng: 67.0011, offsetMin: 300, method: methodById('karachi'), asrFactor: 2);
    near(hm(t.asr, 300), '16:13');
  });

  test('Makkah Umm al-Qura', () {
    final t = PrayerCalc.compute(date: DateTime(2026, 11, 6), lat: 21.4225, lng: 39.8262, offsetMin: 180, method: methodById('makkah'));
    near(hm(t.fajr, 180), '05:08');
    near(hm(t.isha, 180), '19:12');
  });

  test('Qibla bearing from Karachi is about 270 degrees', () {
    final b = PrayerCalc.qiblaBearing(24.8607, 67.0011);
    expect(b > 260 && b < 280, true);
  });

  test('High latitude summer does not crash and keeps order', () {
    final t = PrayerCalc.compute(date: DateTime(2026, 6, 21), lat: 60.17, lng: 24.94, offsetMin: 180, method: methodById('mwl'));
    String f(DateTime d) => d.toIso8601String();
    final info = 'fajr=${f(t.fajr)} sunrise=${f(t.sunrise)} dhuhr=${f(t.dhuhr)} asr=${f(t.asr)} maghrib=${f(t.maghrib)} isha=${f(t.isha)}';
    expect(t.fajr.isBefore(t.sunrise), true, reason: 'fajr not before sunrise. $info');
    expect(t.maghrib.isBefore(t.isha), true, reason: 'maghrib not before isha. $info');
  });
}
