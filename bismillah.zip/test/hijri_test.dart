import 'package:flutter_test/flutter_test.dart';
import 'package:orbit_islam/hijri.dart';

void main() {
  test('Hijri to Gregorian round trip for 60 years', () {
    for (int k = 0; k < 60 * 366; k += 7) {
      final j = 2460000 + k;
      final h = hFromJdn(j);
      expect(hToJdn(h.y, h.m, h.d), j);
      expect(h.m >= 1 && h.m <= 12, true);
      expect(h.d >= 1 && h.d <= 30, true);
    }
  });

  test('1 Ramadan 1447 is 17 Feb 2026 in tabular calendar (may differ by a day from sighting)', () {
    final g = jdnToG(hToJdn(1447, 9, 1));
    expect(g.year, 2026);
    expect(g.month, 2);
    expect(g.day, 17);
  });

  test('today 7 Nov 2026 converts to 27 Jumada al-Awwal 1448', () {
    final h = hFromJdn(gToJdn(DateTime(2026, 11, 7)));
    expect(h.y, 1448);
    expect(h.m, 5);
    expect(h.d, 27);
  });
}
